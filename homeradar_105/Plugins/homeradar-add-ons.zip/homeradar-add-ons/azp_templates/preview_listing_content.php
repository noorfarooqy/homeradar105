<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $images_to_show = $hide_address = $hide_excerpt = $hide_features = $hide_cats = $hide_price_range = 
$hide_contacts = $hide_view_map = $hide_gallery = $hide_footer = $show_price = $show_locations = $show_web = $disable_address_url = '';
$num_feature = $show_pricerange = $hide_author = $hide_rating = $show_logo = $show_area = $show_beds = $show_baths = '';
// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'preview_listing_content',
    'azp-element-' . $azp_mID,
    'geodir-category-content',
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
$website = get_post_meta( get_the_ID(), ESB_META_PREFIX.'website', true );
// if(has_post_thumbnail( )){ ?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>

    
    <h3 class="title-sin_item dis-flex-wrap-center">
        <?php if( $GLOBALS['is_lad'] ) echo '<span class="litem-ad">'._x( 'AD', 'Listing card', 'homeradar-add-ons' ).'</span>'; ?>
        <a href="<?php the_permalink(  ); ?>"><?php 
            the_title(); 
            // $title = get_the_title( get_the_ID() );
            // echo substr($title, 0, 100);
        ?></a>
        <?php if( get_post_meta( get_the_ID(), ESB_META_PREFIX.'verified', true ) == '1' ): ?>
            <span class="verified-badge tolt" data-microtip-position="top" data-tooltip="<?php echo esc_attr_x( 'Verified', 'Listing card', 'homeradar-add-ons' ); ?>"><i class="far fa-check"></i></span>
        <?php endif; ?>
    </h3>
    <?php 
    $price_from = get_post_meta( get_the_ID(), '_price', true );
    if( $show_price == 'yes' && !empty($price_from) ){
        ?><div class="geodir-category-content_price"><?php echo homeradar_addons_get_price_string($price_from); ?></div><?php
        
    }

    $price_to = get_post_meta( get_the_ID(), ESB_META_PREFIX.'price_to', true );
    if( $show_pricerange == 'yes' && !empty($price_to) ) :  ?>
    <div class="lcard-price lcard-pricerange">
    <?php 
        _ex( 'Price range: ','Listing card', 'homeradar-add-ons' );
        echo '<span class="lpricerange-prices"><strong class="lpricerange-from">'.homeradar_addons_get_price_formated($price_from).'</strong>';
        if( !empty($price_to) ) echo '<strong class="lpricerange-to">'. sprintf( _x( ' - %s', 'Listing card', 'homeradar-add-ons' ), homeradar_addons_get_price_formated($price_to) ) .'</strong>';
        echo '</span>';
    ?>
    </div>
    <?php 
    endif; ?>
    <div class="geodir-card-text">
        <?php 
        if( $hide_excerpt != 'yes'): ?>
        <div class="geodir-card-excerpt"><?php homeradar_addons_the_excerpt_max_charlength( homeradar_addons_get_option('excerpt_length','55') ); ?></div>
        <?php endif;
        ?>
        <?php 
        if( $show_locations == 'yes' ){
            $terms = wp_get_post_terms( get_the_ID(), 'listing_location', array( "fields" => "ids" ) );
            if ( $terms && ! is_wp_error( $terms ) ){ 
                $terms = trim( implode( ',', (array) $terms ), ' ,' );
                wp_list_categories( 'style=flat&separator=&title_li=&taxonomy=' . 'listing_location' . '&include=' . $terms );
            }
        } ?>
        <div class="lcfields-wrap dis-flex-wrap-center"><?php echo wp_kses_post( $azp_content ); ?></div>
        <?php 
        // ESB_META_PREFIX
        // house_size
        // // accomodation
        // yard_size
        // bedrooms
        // bathrooms
        // garage 
        if( $show_beds == 'yes' || $show_baths == 'yes' || $show_area == 'yes' ):
        $beds = get_post_meta( get_the_ID(), ESB_META_PREFIX.'bedrooms', true );
        $baths = get_post_meta( get_the_ID(), ESB_META_PREFIX.'bathrooms', true );
        $house_size = get_post_meta( get_the_ID(), ESB_META_PREFIX.'house_size', true );
        ?>
        <div class="geodir-category-content-details">
            <ul class="no-list-style dis-flex-wrap">
                <?php if( $show_beds == 'yes' && !empty($beds) ): ?><li><i class="fal fa-bed"></i><span><?php echo esc_html($beds); ?></span></li><?php endif; ?>
                <?php if( $show_baths == 'yes' && !empty($baths) ): ?><li><i class="fal fa-bath"></i><span><?php echo esc_html($baths); ?></span></li><?php endif; ?>
                <?php if( $show_area == 'yes' && !empty($house_size) ): ?><li><i class="fal fa-cube"></i><span><?php // echo esc_html($house_size); ?> <?php echo homeradar_echo_area_size($house_size); ?></span></li><?php endif; ?>
            </ul>
        </div>
        <?php endif; ?>


        <?php 
        if( $hide_features != 'yes'):
        $terms = get_the_terms(get_the_ID(), 'listing_feature');
        if ( $terms && ! is_wp_error( $terms ) ){  
        ?>
        <div class="geodir-category-content-details">
            <ul class="no-list-style mrg-0 dis-inflex">
                <?php 
                $count = 1;
                foreach ($terms as $term) {
                    if($count > (int)$num_feature) break;
                    $term_metas = homeradar_addons_custom_tax_metas($term->term_id, 'listing_feature'); 
                    //get_term_meta( $term->term_id, ESB_META_PREFIX.'term_meta', true );
                    ?>
                    <li class="tolt"  data-microtip-position="top" data-tooltip="<?php echo esc_attr( $term->name ); ?>">
                        <a href="<?php echo homeradar_addons_get_term_link( $term->term_id, 'listing_feature' ); ?>"><i class="<?php echo esc_attr( $term_metas['icon'] ); ?>"></i></a>
                    </li>
                    <?php
                    $count++;
                }
                ?>
            </ul>
        </div>
        <?php } 
        endif;
        ?>
        <?php 
        global $post;
        if( isset($post->listing_distance) && !empty($post->listing_distance) ){
            echo '<div class="lcard-distance">';
                echo sprintf(_x( 'Distance: <strong>%s km</strong>', 'Listing card', 'homeradar-add-ons' ), number_format($post->listing_distance,1) );
            echo '</div>';
        }
        do_action( 'cth_listing_card_content' );
        ?>
    </div>
    <?php if( $hide_footer != 'yes' ): ?>
    <div class="geodir-category-footer dis-flex-wrap-center jtf-space-between">
        <?php if( $hide_author != 'yes' ): ?>
        <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>" class="gcf-company"><?php
            echo get_avatar(get_the_author_meta('user_email'), '80', 'https://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=80', get_the_author_meta('display_name'));
            ?><span class="lcard-avatar"><?php echo sprintf(_x('By %s', 'Listing card', 'homeradar-add-ons'), get_the_author()); ?></span></a>
        <?php endif; ?>
        <?php 
        if( $show_logo == 'yes' ){ 
            $llogo = get_post_meta( get_the_ID(), ESB_META_PREFIX.'llogo', true );
            if( !empty($llogo) ){
                if( !is_array($llogo) ) $llogo = explode(",", $llogo);
        ?>
        <div class="lcard-logo lcard-grid">
            <a class="lcard-logo-link" href="<?php the_permalink();?>"><?php echo wp_get_attachment_image( $llogo[0], 'thumbnail', false, array('class'=>'llogo-img') );  ?></a>
        </div>
        <?php }
        } ?>
        <?php 
        if( $hide_rating != 'yes' ):
        $rating = homeradar_addons_get_average_ratings(get_the_ID());    ?>
        <?php if( $rating != false ): ?>
            <div class="listing-rating card-popup-rainingvis tolt" data-microtip-position="top" data-tooltip="<?php echo homeradar_addons_rating_text($rating['sum']); ?>" data-stars="<?php echo (int)homeradar_addons_get_option('rating_base');?>" data-rating="<?php echo $rating['sum']; ?>"></div>
        <?php endif;
        endif; ?>  
    
        
    </div>
    <?php endif; ?>

        

</div>
<?php // }
