<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = $desc = $images_to_show = $show_contact =  $hide_widget_on = $show_claim = $hide_on_claimed = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'calc_mortgage',
    'azp-element-' . $azp_mID, 
    $el_class,
);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
    $price_from = get_post_meta( get_the_ID(), '_price', true );
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>

	<div class="box-widget-content fl-wrap color-bg">
        <div class="color-form reset-action">
            <div class="color-form-title fl-wrap"><?php if($title != ''): ?><h3><?php echo $title; ?></h3><?php endif; ?><?php if($desc != ''): ?><p><?php echo $desc; ?></p><?php endif; ?></div>
            <form method="post" name="mortgage-form" class="lmortgage-form">
                <div class="fl-wrap loan-amount-wrap">
                    <label for="amt"><?php _ex( 'Loan Amount', 'Mortgage form', 'homeradar-add-ons' ); ?></label>   
                    <input id="amt" name="amt" type="text" value="<?php echo homeradar_addons_get_price( $price_from ); ?>"> 
                    <div class="use-current-price tolt" data-price="<?php echo homeradar_addons_get_price( $price_from ); ?>" data-microtip-position="left" data-tooltip="<?php esc_attr_e( 'Use current price', 'homeradar-add-ons' ); ?>"><i class="fal fa-tag"></i></div>
                </div>
                <label for="apr"><?php _ex( 'Percentage rate', 'Mortgage form', 'homeradar-add-ons' ); ?></label>
                <div class="price-rage-item fl-wrap">
                    <input type="text" id="apr" name="apr" class="price-range" data-min="1" data-max="100" data-step="1" value="1" data-prefix="%">
                </div>
                <label for="trm"><?php _ex( 'Loan Term (Years)', 'Mortgage form', 'homeradar-add-ons' ); ?></label>
                <div class="price-rage-item fl-wrap">
                    <input type="text" id="trm" name="trm" class="price-range" data-min="0.5" data-max="5" data-step="0.5" value="1" data-prefix="Y">
                </div>
                <div class="clearfix"></div>
                <div class="calc-mortgage-btns flex-items-center jtf-space-between mt-20">
                    <button type="submit" class="subm-mortgage color2-bg"><?php _ex( 'Calculate', 'Mortgage form', 'homeradar-add-ons' ); ?></button>
                    <div class="reset-form reset-btn"> <i class="far fa-sync-alt"></i><?php _ex( 'Reset Form', 'Mortgage form', 'homeradar-add-ons' ); ?></div>
                </div>
                <div class="monterage-title fl-wrap flex-items-center jtf-space-between">
                    <h5><?php _ex( 'Monthly payment:', 'Mortgage form', 'homeradar-add-ons' ); ?></h5>
                    <div class="monterage-title-item"><?php echo homeradar_addons_get_currency_symbol(); ?><span>0</span></div>
                </div>
            </form>
        </div>
    </div>

</div>
<?php endif;

