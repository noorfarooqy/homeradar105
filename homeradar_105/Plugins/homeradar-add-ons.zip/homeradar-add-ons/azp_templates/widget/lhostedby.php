<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = $images_to_show = $show_contact =  $hide_widget_on = $show_claim = $hide_on_claimed = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'lhostedby',
    'azp-element-' . $azp_mID, 
    $el_class,
);

$lverified = get_post_meta( get_the_ID() , ESB_META_PREFIX.'verified', true );

if( $hide_on_claimed == 'yes' && $lverified  === '1' ) return;

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>

	<!--box-widget-item -->
    <div class="box-widget-item fl-wrap block_box">
        <?php if($title != ''): ?>
        <div class="box-widget-item-header">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <?php 
	    $author_ID = get_the_author_meta( 'ID' );
     
        $au_phone = get_user_meta( $author_ID, '_cth_phone', true );
        $au_address = get_user_meta( $author_ID, '_cth_address', true ); 
        $au_url = get_the_author_meta('user_url');
        $au_email = Esb_Class_Emails::luser_email( get_userdata($author_ID) );
                    

	    ?>
        <div class="box-widget">
            <div class="profile-widget">
                <div class="profile-widget-header color-bg smpar fl-wrap">
                    <div class="pwh_bg"></div>
                    <?php if($au_phone != ''){ ?><div class="call-btn"><a href="tel:<?php echo esc_attr( $au_phone ); ?>" class="tolt color-bg" data-microtip-position="right"  data-tooltip="<?php esc_attr_e( 'Call Now', 'homeradar-add-ons' ); ?>"><i class="fas fa-phone-alt"></i></a></div><?php } ?>
                    <?php if( $show_claim == 'yes' && $lverified !== '1' ): ?>
                    <div class="lhead-more-wrap">
                        <div class="box-widget-menu-btn smact"><i class="far fa-ellipsis-h"></i></div>
                        <div class="show-more-snopt-tooltip bxwt">
                            
                            <div class="claim-widget-link fl-wrap">
                                <?php // _e( '<span>Own or work here?</span>', 'homeradar-add-ons' ); ?>
                                <?php if(is_user_logged_in()) : ?>
                                <a class="open-listing-claim" href="#">
                                <?php else : 
                                    $logBtnAttrs = homeradar_addons_get_login_button_attrs( 'claim', 'current' );
                                ?>
                                <a class="<?php echo esc_attr( $logBtnAttrs['class'] );?>" href="<?php echo esc_url( $logBtnAttrs['url'] );?>" data-message="<?php esc_attr_e( 'You must be logged in to claim listing.', 'homeradar-add-ons' ); ?>">
                                <?php endif; ?>
                                    <?php _e( 'Claim Now!', 'homeradar-add-ons' ); ?>
                                </a>
                                
                            </div>
                            
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="profile-widget-card">
                        <div class="profile-widget-image">
                            <?php 
                                echo get_avatar(get_the_author_meta('user_email'),'150','https://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=150', get_the_author_meta('display_name') );
                            ?>
                        </div>
                        <div class="profile-widget-header-title">
                            <h4><a href="<?php echo get_author_posts_url( $author_ID ); ?>"><?php echo get_the_author_meta('display_name');?></a></h4>
                            <div class="clearfix"></div>
                            <div class="pwh_counter"><?php echo sprintf(_x( '<span>%d</span>Property Listings', 'Hostedby widget', 'homeradar-add-ons' ), count_user_posts( $author_ID , "listing" , true ) ) ?></div>
                            <div class="clearfix"></div>
                            <div class="listing-rating card-popup-rainingvis" data-rating="4" data-stars="5"></div>
                        </div>
                    </div>
                </div>
                <div class="profile-widget-content fl-wrap">
                    <div class="contats-list fl-wrap">
                        <ul class="no-list-style">
                            <?php if($au_address != ''){ ?><li><span><i class="fal fa-map-marker"></i><?php _e( 'Address :', 'homeradar-add-ons' ); ?></span> <a href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode($au_address) ;?>"><?php echo esc_html( $au_address ); ?></a></li><?php } ?>
                            <?php if($au_phone != ''){ ?><li><span><i class="fal fa-phone"></i><?php _e( 'Phone :', 'homeradar-add-ons' ); ?></span> <a href="tel:<?php echo esc_attr( $au_phone ); ?>"><?php echo esc_html( $au_phone ); ?></a></li><?php } ?>
                            <?php if($au_email != ''){ ?><li><span><i class="fal fa-envelope"></i><?php _e( 'Mail :', 'homeradar-add-ons' ); ?></span> <a href="mailto:<?php echo esc_attr( $au_email ); ?>"><?php echo esc_html( $au_email ); ?></a></li><?php } ?>
                            
                            <?php if($au_url != ''){ ?><li><span><i class="fal fa-browser"></i><?php _e( 'Website :', 'homeradar-add-ons' ); ?></span> <a href="<?php echo esc_url( $au_url ); ?>" target="_blank"><?php echo esc_html($au_url); ?></a></li><?php } ?>
                        </ul>
                    </div>
                    <div class="profile-widget-footer flex-items-center jtf-space-between">
                        <a href="<?php echo get_author_posts_url( $author_ID ); ?>" class="btn float-btn color-bg small-btn"><?php _e( 'View Profile', 'homeradar-add-ons' ); ?></a>
                        <div class="profile-custom-link"><a href="#sec-contact" class="custom-scroll-link tolt" data-microtip-position="left"  data-tooltip="<?php esc_attr_e( 'Viewing Property', 'homeradar-add-ons' ); ?>"><i class="fal fa-paper-plane"></i></a></div>
                    </div>
                </div>
            </div>
                    

        </div>
    </div>
    <!--box-widget-item end -->  

</div>
<?php endif;

