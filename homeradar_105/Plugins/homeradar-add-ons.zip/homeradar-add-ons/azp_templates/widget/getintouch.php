<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $hide_widget_on = $hide_email = $hide_map = $title = $hide_phone = $hide_message = '';
$dformat = '';
// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'getintouch mt-20',
    'azp-element-' . $azp_mID,  
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
// $listing_author_id = get_the_author_meta('ID');
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :

    $lauthor_id = get_post_field( 'post_author', get_the_ID() );

    $current_user = wp_get_current_user();
    
    $loggedName = '';
    $loggedEmail = '';
    $loggedPhone = '';
    if( is_user_logged_in() ){
        $loggedName = $current_user->display_name;
        $loggedEmail = get_user_meta($current_user->ID,  ESB_META_PREFIX.'email', true );
        if( empty($loggedEmail) ) $loggedEmail = $current_user->user_email;
        $loggedPhone = get_user_meta($current_user->ID,  ESB_META_PREFIX.'phone', true );
    }
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
    <!--box-widget-item -->
    <div class="box-widget-item fl-wrap lbox-widget-contact" id="sec-contact">
        <?php if($title != ''): ?>
        <div class="box-widget-title fl-wrap box-widget-title-color color-bg"><?php echo $title; ?></div>
        <?php endif; ?>
        <div class="box-widget-content fl-wrap">
            <div class="custom-formsss">
                <form class="author-message-form custom-form" action="#" method="post">
                    <?php do_action( 'homeradar_author_contact_form_before', $lauthor_id ); ?>
                    <fieldset>
                        <div class="hasIcon mb-20">
                            <label><?php esc_html_e( 'Your Name*', 'homeradar-add-ons' ); ?><span class="dec-icon"><i class="fas fa-user"></i></span></label>
                            <input name="lmsg_name" class="has-icon" type="text" placeholder="<?php esc_attr_e( 'Your Name*', 'homeradar-add-ons' ); ?>" value="<?php echo esc_attr( $loggedName ); ?>" required="required">
                        </div>

                        <div class="hasIcon mb-20">
                            <label><?php esc_html_e( 'Email Address*', 'homeradar-add-ons' ); ?><span class="dec-icon"><i class="fas fa-envelope"></i></span></label>
                            <input name="lmsg_email" class="has-icon" type="text" placeholder="<?php esc_attr_e( 'Email Address*', 'homeradar-add-ons' ); ?>" value="<?php echo esc_attr( $loggedEmail ); ?>" required="required">
                        </div>
                        <?php if( $hide_phone != 'yes' ): ?>
                        <div class="hasIcon mb-20">
                            <label><?php esc_html_e( 'Phone*', 'homeradar-add-ons' ); ?><span class="dec-icon"><i class="fas fa-phone"></i></span></label>
                            <input name="lmsg_phone" class="has-icon" type="text" placeholder="<?php esc_attr_e( 'Phone', 'homeradar-add-ons' ); ?>" value="<?php echo esc_attr( $loggedPhone ); ?>" required="required">
                        </div>
                        <?php endif; ?>
                        <?php if( $hide_message != 'yes' ): ?>
                        <div class="mb-20">
                            <label><?php esc_html_e( 'Details*', 'homeradar-add-ons' ); ?></label>
                            <textarea class="mb-20s" name="lmsg_message" cols="40" rows="3" placeholder="<?php esc_attr_e( 'Details:', 'homeradar-add-ons' ); ?>" required="required"></textarea>
                        </div>
                        <?php endif; ?>
                    </fieldset>
                    
                    <div class="row mb-20">
                        <div class="col-sm-7">
                            <div class="cth-date-picker-wrap hasIcon">
                                <label><?php esc_html_e( 'Date', 'homeradar-add-ons' ); ?><span class="dec-icon"><i class="fas fa-calendar-check"></i></span></label>
                                <div class="cth-date-picker cth-date-picker-hide-metas" 
                                    data-name="checkin" 
                                    data-format="<?php echo $dformat; ?>" 
                                    data-default="current"
                                    data-action="" 
                                    data-postid="" 
                                    data-selected="general_date"
                                    data-required="yes"
                                    data-placeholder="" data-show="no"
                                ></div>
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <label><?php esc_html_e( 'Time', 'homeradar-add-ons' ); ?></label>
                            <select name="time" data-placeholder="9 AM" class="chosen-select on-radius no-search-select">
                                <option value="09:00:00">9 AM</option>
                                <option value="10:00:00">10 AM</option>
                                <option value="11:00:00">11 AM</option>
                                <option value="12:00:00">12 AM</option>
                                <option value="13:00:00">13 PM</option>
                                <option value="14:00:00">14 PM</option>
                                <option value="15:00:00">15 PM</option>
                                <option value="16:00:00">16 PM</option>
                            </select>
                        </div>
                    </div>

                    <?php do_action( 'homeradar_author_contact_form_after', $lauthor_id ); ?>
                    <div class="author-message-error"></div>
                    <button class="btn color-bg fw-btn author-msg-submit" type="submit"><?php _e( 'Send', 'homeradar-add-ons' ); ?></button>
                    <input type="hidden" name="authid" value="<?php echo $lauthor_id; ?>">
                    <input type="hidden" name="listing_id" value="<?php the_ID(); ?>">
                </form>

            </div>
        </div>
    </div>
</div>

<?php endif; 

