<?php
/* add_ons_php */



//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $posts_per_page = $order_by = $order = $title = $responsive = $taxonomy = $hide_widget_on = '';  

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
    'azp_element',
    'lsimilar_listings',
    'azp-element-' . $azp_mID,
    $el_class,
);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );  

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}

if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :

    if( $taxonomy == 'featured' ){
        $post_args = array(
            'post_type'         => 'listing',  
            'post__not_in'      => array(get_the_ID()),
            'orderby'           => $order_by,
            'order'             => $order, 
            'posts_per_page'    => $posts_per_page,
            'meta_query'   => array(
                array(
                    'key'     => ESB_META_PREFIX .'featured',
                    'value'   => '1',
                    'type'      => 'NUMERIC'
                )
            ),
        );
    }else{
        $terms_ids = array();
        $terms = get_the_terms( get_the_ID(), $taxonomy );
        if ( $terms && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $terms_ids[] = $term->term_id;
            }
        }
        $post_args = array(
            'post_type'         => 'listing',  
            'post__not_in'      => array(get_the_ID()),
            'orderby'           => $order_by,
            'order'             => $order, 
            'posts_per_page'    => $posts_per_page,
            'tax_query' => array(
                array(
                    'taxonomy' => $taxonomy,
                    'field'    => 'term_id',
                    'terms'    => $terms_ids,
                ),
            ),
            // 'meta_query'   => array(
            //     array(
            //         'key'     => ESB_META_PREFIX .'featured',
            //         'value'   => '1',
            //         'type'      => 'NUMERIC'
            //     )
            // ),
        );
    }
$posts_query = new \WP_Query($post_args);
if($posts_query->have_posts()) : ?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
    <!--box-widget-item -->
    <div class="lsingle-block-box lsimilarslider-block">
        <?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lsingle-block-content">
                <?php 
                $slider_args = array();
                $breakpoints = array();
                $slidesPerView = array();
                $responsive = explode( ",", trim($responsive) );
                if( !empty($responsive) ){
                    foreach ($responsive as $breakpoint) {
                        $breakpoint = explode( ":", trim($breakpoint) );
                        if( count($breakpoint) === 2 ){
                            $breakpoints[] = array( 'breakpoint' => intval($breakpoint[0]), 'settings' => array( 'slidesToShow'=>intval($breakpoint[1]) ) );
                            $slidesPerView[] = intval($breakpoint[1]);
                        }
                    }
                }
                if( !empty($breakpoints) ){
                    usort($breakpoints, function($a, $b) {
                        return $b['breakpoint'] - $a['breakpoint'];
                    });
                    $slider_args['slidesToShow'] = max($slidesPerView);
                    $slider_args['responsive'] = $breakpoints;
                }
                ?>
                <div class="single-carousel-wrap carousel-wrap similar-listings-slider-wrap airbnb-style">
                    <div class="single-carousel carousel" data-options='<?php echo json_encode($slider_args); ?>'>
                        <?php 
                        while($posts_query->have_posts()) : $posts_query->the_post(); 
                            homeradar_addons_get_template_part( 'template-parts/listing', false, array( 
                                'for_slider'    => true, 
                                'hide_status'   => 'yes', 
                                'hide_featured' => 'yes',
                                'hide_author'   => 'yes',
                            ) );
                        endwhile; ?>
                    </div>
                    <div class="crs-button-prev lc-wbtn lc-wbtn_prev"><i class="fal fa-angle-left"></i></div>
                    <div class="crs-button-next lc-wbtn lc-wbtn_next"><i class="fal fa-angle-right"></i></div>
                </div>

        </div>
    </div>
    <!--box-widget-item end -->  
</div> 
<?php endif;
wp_reset_postdata();

endif;// check hide on plans 

