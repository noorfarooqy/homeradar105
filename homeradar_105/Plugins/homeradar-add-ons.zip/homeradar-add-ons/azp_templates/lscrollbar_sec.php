<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
// var_dump($azp_attrs);
$azp_mID = $el_id = $el_class = $hstyle = $menus = $show_mobile = $hide_report = $hide_review = $hide_share = $hide_bookmark = $show_addtocal = '';
extract($azp_attrs);

$classes = array(
	'azp_element',
    'lscrollbar_sec',
    'azp-element-' . $azp_mID, 
    $el_class,
);
$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );    
if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
$menus = json_decode(urldecode($menus) , true) ;
?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>                     
	<!-- scroll-nav-wrapper--> 
    <div class="scroll-nav-wrap <?php echo 'lscroll-mobile-'.$show_mobile; ?>">
        
        	
        		<nav class="scroll-nav scroll-init fixed-column_menu-init">
	                <ul class="no-list-style">
	                    
	                    <?php if (!empty($menus) && $menus != '') {
	                        foreach ($menus as $menu) { 
	                            $icon = '';
	                            $nv_cls = 'sclnav-item';
	                            if(isset($menu['show_mobile'])) $nv_cls .= ' sclnav-item-mobile-'.$menu['show_mobile'];
	                            if(!empty($menu['icon'])) $icon = '<i class="'.$menu['icon'].'"></i>';
	                        ?>
	                            <li  class="<?php echo esc_attr( $nv_cls ); ?>"><a href="<?php echo $menu['sec_id']; ?>"><?php echo $icon; ?></a><span><?php echo $menu['title'];?></span></li>                  
	                    <?php   } 
	                        }
	                    if ( comments_open() || get_comments_number() )  echo '<li class="sclnav-item sclnav-lreview"><a href="#lreviews_sec"><i class="fal fa-comment-alt-lines"></i></a><span>'.__( ' Reviews', 'homeradar-add-ons' ).'</span></li>';
	                    ?>
	                </ul>
	                <div class="progress-indicator">
	                    <svg xmlns="http://www.w3.org/2000/svg"
	                        viewBox="-1 -1 34 34">
	                        <circle cx="16" cy="16" r="15.9155"
	                            class="progress-bar__background" />
	                        <circle cx="16" cy="16" r="15.9155"
	                            class="progress-bar__progress 
	                            js-progress-bar" />
	                    </svg>
	                </div>
	            </nav>
	            
        	
        
    </div>
    <!-- scroll-nav-wrapper end--> 
</div>