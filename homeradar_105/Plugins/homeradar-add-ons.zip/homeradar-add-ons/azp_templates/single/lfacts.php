<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = $sec_id = $cols = $hide_widget_on = ''; 

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
    'azp_element',
	'lfacts',
	'azp-element-' . $azp_mID,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs); 
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );  

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
$facts = get_post_meta( get_the_ID(), ESB_META_PREFIX.'facts', true );
if ( is_array( $facts) && !empty($facts)) {
    if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
    <!-- lsingle-block-box --> 
    <div class="lsingle-block-box no-padding lfacts-block">
        <?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lsingle-block-content">
            <div class="lsingle-facts <?php echo $cols ?>-cols">
                <?php 
                foreach( $facts as $key => $fact): ?>
                <!-- inline-facts -->
                <div class="inline-facts-wrap flex-fact-wrap">
                    <div class="inline-facts">
                        <?php if( !empty($fact['icon']) ): ?><i class="lfact-icon <?php echo esc_attr($fact['icon']); ?>"></i><?php endif; ?>
                        <div class="lfact-details">
                            <?php if( !empty($fact['title']) ): ?><h6 class="lfact-title"><?php echo esc_html($fact['title']); ?></h6><?php endif; ?>
                            <?php if( !empty($fact['title']) ): ?><span class="lfact-num"><?php echo esc_html($fact['number']); ?></span><?php endif; ?>
                        </div>
                        
                    </div>
                </div>
                <!-- inline-facts end -->
            <?php
            endforeach; ?>
            </div>
        </div>
    </div>
    <!-- lsingle-block-box end -->  
</div>
<?php 
    endif;// check hide on plans
} 
