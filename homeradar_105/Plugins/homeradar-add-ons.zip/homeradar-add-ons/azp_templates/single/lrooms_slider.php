<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = $responsive = $order_by = $order = $hide_widget_on = ''; 

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'azp_rooms_slider',
    'azp-element-' . $azp_mID,
    $el_class,
);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );  

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
$lrooms = get_post_meta( get_the_ID(), ESB_META_PREFIX.'rooms_ids', true );  
$listing_type_ID = get_post_meta( get_the_ID(), ESB_META_PREFIX.'listing_type_id', true );
$child_pt = get_post_meta( $listing_type_ID, ESB_META_PREFIX.'child_type_meta', true );
$child_type = ($child_pt == 'product') ? 'product' : 'lrooms';
if (!empty($lrooms)) {
?>
<div class="<?php echo $classes;?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
    <div class="lsingle-block-box lroomsslider-block">
        <?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lsingle-block-content">
            <?php 
            $slider_args = array();
            $breakpoints = array();
            $slidesPerView = array();
            $responsive = explode( ",", trim($responsive) );
            if( !empty($responsive) ){
                foreach ($responsive as $breakpoint) {
                    $breakpoint = explode( ":", trim($breakpoint) );
                    if( count($breakpoint) === 2 ){
                        $breakpoints[] = array( 'breakpoint' => intval($breakpoint[0]), 'settings' => array( 'slidesToShow'=>intval($breakpoint[1]) ) );
                        $slidesPerView[] = intval($breakpoint[1]);
                    }
                }
            }
            if( !empty($breakpoints) ){
                usort($breakpoints, function($a, $b) {
                    return $b['breakpoint'] - $a['breakpoint'];
                });
                $slider_args['slidesToShow'] = max($slidesPerView);
                $slider_args['responsive'] = $breakpoints;
            }
            $args = array(
                'post_type'         => $child_type,
                'post_status'       => 'publish',
                'post__in'          => $lrooms,
                'posts_per_page'    => -1,
                // 'author'            => $current_user->ID,
                'orderby'           => $order_by,
                'order'             => $order,

            );
            $posts_query = new \WP_Query($args);
            if($posts_query->have_posts()) :
            ?>
            <div class="single-carousel-wrap carousel-wrap lrooms-carousel-wrap">
                <div class="single-carousel carousel" data-options='<?php echo json_encode($slider_args); ?>'>
                    <?php 
                    while($posts_query->have_posts()) : $posts_query->the_post();  ?>
                        <div class="room-box slick-slide-item">
                            <?php 
                                echo homeradar_addons_azp_parser_listing( $listing_type_ID  , 'preview_room', get_the_ID() );
                            ?>
                        </div>
                    <?php 
                    endwhile; ?>
                </div>
                <div class="crs-button-prev lc-wbtn lc-wbtn_prev"><i class="fal fa-angle-left"></i></div>
                <div class="crs-button-next lc-wbtn lc-wbtn_next"><i class="fal fa-angle-right"></i></div>
            </div>      
            <?php endif; ?>
            <?php wp_reset_postdata(); ?>    
        </div> 
    </div>
</div>
<?php 
    } 
endif;// check hide on plans
