<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = '';
$show_counter = $hide_title = '';
$hide_status = $show_share = '';
$hide_rating = $hide_cats = $hide_author = $hide_views = $hide_bookmarks = $hide_address = $hide_phone = $hide_email = $show_logo = $show_web = $disable_address_url = $hide_price = $hide_date = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'lheadinfo',
    'azp-element-' . $azp_mID,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>

	<!-- lsingle-block-box --> 
    <div class="lsingle-block-boxex lheadinfo-block">
    	<?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lheadinfo-inner-wrap">
            
            
            <!--  list-single-opt_header-->
            <div class="list-single-opt_header fl-wrap dis-flex jtf-space-between">
                <?php 
                if( $hide_cats != 'yes'){
                 ?>
                <div class="list-single-opt_header_cat dis-flex-wrap">
                    <?php
                    $statuses = get_the_terms(get_the_ID(), 'listing_status'); 
                    if ( $statuses && ! is_wp_error( $statuses ) ){
                        foreach( $statuses as $key => $tax){
                            $term_metas = homeradar_addons_custom_tax_metas($tax->term_id); 
                            echo sprintf( '<a href="%1$s" class="cat-opt status-opt flex-items-center">%2$s</a> ',
                                homeradar_addons_get_term_link( $tax->term_id, 'listing_status' ),
                                esc_html( $tax->name ),
                            );
                        }
                    }
                    ?>
                    <?php 
                    $cats = get_the_terms(get_the_ID(), 'listing_cat');
                    if ( $cats && ! is_wp_error( $cats ) ){
                        foreach( $cats as $key => $cat){
                            $term_metas = homeradar_addons_custom_tax_metas($cat->term_id); 
                            // echo sprintf( '<a href="%1$s" class="cat-opt flex-items-center %2$s">%4$s<span>%3$s</span></a> ',
                            echo sprintf( '<a href="%1$s" class="cat-opt flex-items-center">%3$s</a> ',
                                homeradar_addons_get_term_link( $cat->term_id, 'listing_cat' ),
                                $term_metas['color'],
                                esc_html( $cat->name ),
                                ($term_metas['icon'] != '' ? '<i class="'.$term_metas['icon'].'"></i>' : ''),
                                $term_metas['color']
                            );
                        }
                    }
                    ?>
                </div>
                <?php
                } ?>
                <?php if($show_share == 'yes') homeradar_addons_echo_socials_share(); ?>
            </div>
            <!--  list-single-opt_header end -->


            


            <!--  list-single-header-item-->
            <div class="list-single-header-item  fl-wrap">
                <div class="lheadinfo-top-wrap dis-flex jtf-space-between">
                    <div class="lheadinfo-top-left">
                        <?php if($hide_title != 'yes'): ?><h1 class="lhead-title">
                            <?php the_title( ) ;?>
                            <?php if( get_post_meta( get_the_ID(), ESB_META_PREFIX.'verified', true ) == '1' ): ?><span class="verified-badge tolt" data-microtip-position="bottom"  data-tooltip="<?php _ex( 'Verified', 'Listing head', 'homeradar-add-ons' ); ?>"><i class="fas fa-check"></i></span><?php endif; ?>
                            <?php homeradar_addons_edit_listing_link(get_the_ID());?>
                        </h1>
                        <?php endif; ?>
                        <div class="lheadinfo-left-bot fl-wrap">
                            <div class="geodir-category-location dis-flex-wrap">
                            <?php 
                            $phone = get_post_meta( get_the_ID(), ESB_META_PREFIX.'phone', true );
                            $email = get_post_meta( get_the_ID(), ESB_META_PREFIX.'email', true );
                            $website = get_post_meta( get_the_ID(), ESB_META_PREFIX.'website', true );
                            $address = get_post_meta( get_the_ID(), ESB_META_PREFIX.'address', true );
                            $latitude = get_post_meta( get_the_ID(), ESB_META_PREFIX.'latitude', true );
                            $longitude = get_post_meta( get_the_ID(), ESB_META_PREFIX.'longitude', true );
                            // if($address != '' ):

                            $address_url = 'javascript:void(0);';
                            if( $disable_address_url != 'yes' && !empty($latitude) && !empty($longitude) ) $address_url = 'https://www.google.com/maps/search/?api=1&query='.esc_attr($latitude).','.esc_attr($longitude);
                            ?>
                                <?php if( $hide_address != 'yes' && $address != '' ): ?><a href="<?php echo $address_url;?>" target="_blank"><i class="fas fa-map-marker-alt"></i><?php echo esc_html($address); ?></a><?php endif; ?>
                                <?php if( $hide_phone != 'yes' && $phone != '' ): ?><a href="tel:<?php echo esc_attr( $phone );?>"> <i class="fal fa-phone"></i><?php echo esc_html($phone) ?></a><?php endif; ?>
                                <?php if( $hide_email != 'yes' && $email != '' ): ?><a href="mailto:<?php echo esc_attr( $email ); ?>"><i class="fal fa-envelope"></i><?php echo esc_html($email) ?></a><?php endif; ?>
                                <?php if( $show_web == 'yes' && !empty($website) ): ?><a href="<?php echo esc_url( $website ); ?>" target="_blank"><i class="fal fa-globe"></i><?php echo esc_html($website) ?></a><?php endif; ?>
                                <?php 
                                if( $hide_rating != 'yes' ):
                                $rating = homeradar_addons_get_average_ratings(get_the_ID());    ?>
                                <?php if( $rating != false ): ?>
                                    <div class="listing-rating card-popup-rainingvis" data-stars="<?php echo (int)homeradar_addons_get_option('rating_base');?>" data-rating="<?php echo $rating['sum']; ?>"><span class="re_stars-title"><?php echo homeradar_addons_rating_text($rating['sum']); ?></span></div>
                                <?php endif;
                                endif; ?>  

                            <?php // endif; ?>
                            </div>
                            <?php do_action( 'cth_listing_header_left' ); ?>
                        </div>
                    </div>
                    <?php 
                    if( $hide_author != 'yes' || $show_logo == 'yes' ){ ?>
                    <div class="lheadinfo-top-right">
                        <div class="lhead-author-logo-wrap flex-items-center jtf-space-between">
                            <?php if( $hide_author != 'yes' ){ ?>
                            <div class="list-single-author host-avatar-wrap">
                                <a class="author_link" href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>"><span class="flex-items-center"><?php
                                echo get_avatar(get_the_author_meta('user_email'), '80', 'https://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=80', get_the_author_meta('display_name'));
                                ?><span class="author_name"><?php echo sprintf( __('By %s', 'homeradar-add-ons'), get_the_author() ); ?></span></span></a>
                            </div>
                            <?php } ?>
                            <?php 
                            if( $show_logo == 'yes' ){ 
                                $llogo = get_post_meta( get_the_ID(), ESB_META_PREFIX.'llogo', true );
                                if( !empty($llogo) ){
                                    if( !is_array($llogo) ) $llogo = explode(",", $llogo);
                            ?>
                            <div class="list-single-logo host-avatar-wrap">
                                <?php echo wp_get_attachment_image( $llogo[0], 'thumbnail', false, array('class'=>'llogo-img') );  ?>
                            </div>
                            <?php }
                            } ?>
                            <?php // homeradar_addons_get_template_part( 'templates-inner/status', '', array( 'show_counter' => $show_counter, 'hide_status' => $hide_status ) ); ?>
                        </div><!-- lhead-author-logo-wrap end -->
                    </div>
                    <?php } ?>
                </div>
                <div class="list-single-header-footer fl-wrap dis-flex jtf-space-between flw-wrap">
                    <div class="lhead-bot-left flex-items-center">
                        <?php
                        $price_from = get_post_meta( get_the_ID(), '_price', true );
                        if( $hide_price != 'yes' && !empty($price_from) ){
                            ?><div class="list-single-header-price"><?php _ex( '<strong>Price:</strong>', 'Listing head', 'homeradar-add-ons' ); ?><?php echo homeradar_addons_get_price_string($price_from); ?></div><?php
                        } ?>
                        <?php if( $hide_date != 'yes' ){ ?>
                        <div class="list-single-header-date"><?php _ex( '<span>Date:</span>', 'Listing head', 'homeradar-add-ons' ); ?><?php the_time(get_option('date_format'));?></div>
                        <?php } ?>
                        <?php do_action( 'cth_listing_bottom_left' ); ?>
                    </div>
                    <div class="lhead-bot-right">
                        <?php if( $hide_views != 'yes' || $hide_bookmarks != 'yes' ){ ?>
                        <div class="list-single-stats">
                            <ul class="no-list-style">
                                <?php if( $hide_views != 'yes' ){ ?>
                                <li><span class="viewed-counter"><i class="fas fa-eye"></i><?php echo sprintf(_x( ' Viewed - %s', 'Listing head', 'homeradar-add-ons' ), Esb_Class_LStats::get_stats(get_the_ID()) ); ?></span></li>
                                <?php } ?>
                                <?php 
                                if( $hide_bookmarks != 'yes' ){
                                    $bookmark_count = Esb_Class_Listing_CPT::get_bookmark_count( get_the_ID() ); 
                                    if( !empty($bookmark_count) ): ?>
                                    <li><span class="bookmark-counter"><i class="fas fa-heart"></i><?php echo sprintf( _x( 'Bookmark -  %d', 'Listing head', 'homeradar-add-ons' ), intval($bookmark_count) ); ?></span></li>
                                    <?php 
                                    endif; 
                                } ?>
                            </ul>
                        </div>
                        <?php } ?>
                        <?php do_action( 'cth_listing_bottom_right' ); ?>
                    </div>
                </div><!-- list-single-header-footer -->
            </div>



        </div><!-- lheadinfo-inner-wrap end -->
    </div>
    <!-- lsingle-block-box end --> 
</div>