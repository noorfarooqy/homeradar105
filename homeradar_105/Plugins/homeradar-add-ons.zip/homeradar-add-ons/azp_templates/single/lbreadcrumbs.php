<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = '';
$hide_report = $hide_review = $hide_share = $hide_bookmark = $show_addtocal = $show_print = $show_compare = '';
// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'lbreadcrumbs',
    'azp-element-' . $azp_mID,
    'breadcrumbs-wrapper inline-breadcrumbs fw-breadcrumbs sp-brd fl-wrap',
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
?>
<!-- breadcrumbs-->
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>
    <div class="container">
        <div class="inline-breadcrumbs-wrap flex-items-center jtf-space-between flw-wrap">
            <?php // if( function_exists('homeradar_get_template_part') ) homeradar_get_template_part( 'template-parts/breadcrumbs', '', array( 'is_top'=>false) ); 
                homeradar_addons_breadcrumbs();
            ?>
            <div class="inline-breadcrumbs-right flex-items-center">

                <?php if( $show_addtocal == 'yes' ) echo do_shortcode( '[add_to_cal]' ); ?>

                <?php if( $hide_bookmark != 'yes' ){
                    echo do_shortcode( '[bookmark_btn]' );
                } 
                
                if($hide_share !='yes'){
                    echo do_shortcode( '[share_btn]' );
                } ?>
                
                <?php if( $show_compare == 'yes' ): ?>
                <a class="compare-top-btn tolt" data-microtip-position="bottom"  data-tooltip="<?php _ex( 'Compare', 'Listing breadcrumbs', 'homeradar-add-ons' ); ?>" href="#"><i class="fas fa-random"></i></a>
                <?php endif; ?>     

                <?php if( $show_print == 'yes' ): ?>
                <a class="print-btn tolt" href="javascript:window.print()" data-microtip-position="bottom"  data-tooltip="<?php _ex( 'Print', 'Listing breadcrumbs', 'homeradar-add-ons' ); ?>"><i class="fas fa-print"></i></a>
                <?php endif; ?>     
                
                <?php if( $hide_review != 'yes' || $hide_report != 'yes' ): ?>
                <div class="lhead-more-wrap">
                    <div class="show-more-snopt smact"><i class="fal fa-ellipsis-v"></i></div>
                    <div class="show-more-snopt-tooltip">
                        <?php if( $hide_review != 'yes' ): ?>
                        <?php if ( comments_open() || get_comments_number() ): ?><a class="custom-scroll-link" href="#lreviews_sec"> <i class="fas fa-comment-alt"></i><?php _ex( 'Write a review', 'Listing breadcrumbs', 'homeradar-add-ons' ); ?></a><?php endif; ?>
                        <?php endif; ?>

                        <?php if( $hide_report != 'yes' ): ?>
                            <?php if( homeradar_addons_get_option('report_must_login') == 'yes' && !is_user_logged_in() ): 
                                $logBtnAttrs = homeradar_addons_get_login_button_attrs( 'report', 'current' );
                            ?>
                            <a href="<?php echo esc_url( $logBtnAttrs['url'] );?>" class="report-listing-btn <?php echo esc_attr( $logBtnAttrs['class'] );?>" data-message="<?php echo esc_attr_x( 'Logging in first to report this listing.', 'Listing breadcrumbs', 'homeradar-add-ons' ); ?>"> <i class="fas fa-exclamation-triangle"></i><?php _ex( 'Report listing', 'Listing breadcrumbs', 'homeradar-add-ons' ); ?></a>
                            <?php else: ?>
                            <a href="#" class="report-listing-btn report-listing-opener" data-id="<?php the_ID(); ?>"><i class="fas fa-exclamation-triangle"></i><?php _ex( 'Report listing', 'Listing breadcrumbs', 'homeradar-add-ons' ); ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>        
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs end -->