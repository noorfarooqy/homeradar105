<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = $hide_widget_on = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'ldescription',
    'azp-element-' . $azp_mID,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
	<!-- lsingle-block-box --> 
    <div class="lsingle-block-box ldesc-block">
    	<?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lsingle-block-content">

            <div class="list-single-main-item_content fl-wrap">
                <div class="details-list">
                    <?php 
                    $rooms = get_post_meta( get_the_ID(), ESB_META_PREFIX.'rooms_ids', true ); 
                    if( is_array($rooms) ) $rooms = count($rooms);
                    else $rooms = 0;
                    $ltype = get_post_meta( get_the_ID(), ESB_META_PREFIX.'listing_type_id', true );
                    if( !empty($ltype) ) $ltype = get_the_title( $ltype );
                    else $ltype = '';
                    $proid = get_post_meta( get_the_ID(), ESB_META_PREFIX.'pid', true );
                    // if( empty($proid) ) $proid = get_the_ID();
                    $_price = get_post_meta( get_the_ID(), ESB_META_PREFIX.'_price', true );
                    $garage = get_post_meta( get_the_ID(), ESB_META_PREFIX.'garage', true );
                    $bedrooms = get_post_meta( get_the_ID(), ESB_META_PREFIX.'bedrooms', true );
                    $bathrooms = get_post_meta( get_the_ID(), ESB_META_PREFIX.'bathrooms', true );
                    $house_size = get_post_meta( get_the_ID(), ESB_META_PREFIX.'house_size', true );
                    ?>
                    <ul class="dis-flex-wrap">
                        <?php if( !empty($proid) ): ?><li class="property-id-li"><span><?php _ex( 'Property Id:', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo get_post_meta( get_the_ID(), ESB_META_PREFIX.'pid', true ); ?></li><?php endif; ?>
                        <?php if( !empty($house_size) ): ?><li class="property-size-li"><span><?php _ex( 'Area Size:', 'Property details', 'homeradar-add-ons' ); ?></span><?php //echo $house_size; ?><?php echo homeradar_echo_area_size($house_size); ?></li><?php endif; ?>
                        <?php if( !empty($bedrooms) ): ?><li class="property-beds-li"><span><?php _ex( 'Bedrooms:', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo $bedrooms; ?></li><?php endif; ?>
                        <?php if( !empty($rooms) ): ?><li class="property-rooms-li"><span><?php _ex( 'Rooms:', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo $rooms; ?></li><?php endif; ?>
                        <?php if( !empty($bathrooms) ): ?><li class="property-baths-li"><span><?php _ex( 'Bathrooms:', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo $bathrooms; ?></li><?php endif; ?>
                        <?php if( !empty($garage) ): ?><li class="property-garage-li"><span><?php _ex( 'Garage Size (Cars):', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo $garage; ?></li><?php endif; ?>
                        <li class="property-date-li"><span><?php _ex( 'Date:', 'Property details', 'homeradar-add-ons' ); ?></span><?php the_time(get_option('date_format')); ?></li>
                        <?php if( !empty($_price) ): ?><li class="property-price-li"><span><?php _ex( 'Price:', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo homeradar_addons_get_price_formated( $_price ); ?></li><?php endif; ?>
                        <?php if( !empty($ltype) ): ?><li class="property-type-li"><span><?php _ex( 'Type:', 'Property details', 'homeradar-add-ons' ); ?></span><?php echo $ltype; ?></li><?php endif; ?>
                    </ul>

                </div>
            </div>
            
        </div>
    </div>
    <!-- lsingle-block-box end -->  

</div>
<?php 
endif;// check hide on plans/ check hide on plans