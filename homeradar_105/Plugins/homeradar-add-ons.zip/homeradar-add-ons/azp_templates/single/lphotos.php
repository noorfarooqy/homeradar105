<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $items_width = $images_to_show = $hide_widget_on = $grid_cols = $space = ''; 

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'lphotos',
    'azp-element-' . $azp_mID, 
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs); 
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );  

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
$images = get_post_meta( get_the_ID(), ESB_META_PREFIX.'images', true );
if( !empty($images) && !is_array($images) ) { 
    $images = explode(",", $images);
    $items_width = explode(',',$items_width); 
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
    <!-- lsingle-block-box --> 
    <div class="lsingle-block-box lphotos-block">
        <?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lsingle-block-content">
            <?php if( !empty($images) ): ?>
            <div class="single-gallery-wrap cthiso-isotope-wrapper">

                <div class="cthiso-items cthiso-<?php echo esc_attr($space);?>-pad cthiso-<?php echo esc_attr($grid_cols);?>-cols clearfix cthiso-flex lightgallery">
                    <!-- <div class="cthiso-sizer"></div> -->
                    <?php
                    foreach ($images as $key => $id ) {
                        $image = get_post($id);
                        if( !$image ) continue;
                        $galCaptionID = uniqid('gal-cap');

                        $tnsize = 'homeradar-gallery-one';
                        $item_cls = 'cthiso-item gallery-item';
                        if(isset($items_width[$key])){
                            switch ($items_width[$key]) {
                                case 'x2':
                                    $item_cls .= ' cthiso-item-second';
                                    $tnsize = 'homeradar-gallery-two';
                                    break;
                                case 'x3':
                                    $item_cls .= ' cthiso-item-three';
                                    $tnsize = 'homeradar-gallery-three';
                                    break;
                            }
                        }

                    ?>
                    <div class="<?php echo esc_attr( $item_cls ); ?>">
                        <div class="grid-item-holder">
                            <div class="box-item">
                                <?php echo wp_get_attachment_image( $id, $tnsize ); ?>
                                <a href="<?php echo wp_get_attachment_url( $id );?>" class="gal-link popup-image" data-sub-html="#<?php echo esc_attr( $galCaptionID );?>">
                                    <i class="fal fa-search"></i>
                                    <?php 
                                    $image_title = $image->post_title;
                                    $image_caption = $image->post_excerpt;
                                    ?>
                                    <div id="<?php echo esc_attr( $galCaptionID );?>" class="gal-caption-hide">
                                        <h3><?php echo esc_html( $image_title ); ?></h3>
                                        <?php echo $image_caption; ?>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                    ?>     
                </div>
            </div>
            <?php endif; ?>           
            
        </div>
    </div>
    <!-- lsingle-block-box end -->  
</div>
<?php  
    } 
endif;// check hide on plans
