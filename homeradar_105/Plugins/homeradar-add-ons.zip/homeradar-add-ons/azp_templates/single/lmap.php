<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $title = $hide_widget_on = '';
// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'lmap-single',
    'azp-element-' . $azp_mID,  
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
if(( $hide_widget_on_check = homeradar_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
$address = get_post_meta( get_the_ID(), ESB_META_PREFIX.'address', true );
$latitude = get_post_meta( get_the_ID(), ESB_META_PREFIX.'latitude', true );
$longitude = get_post_meta( get_the_ID(), ESB_META_PREFIX.'longitude', true );
if( !empty($latitude) && !empty($longitude) ) : 
    $map_provider = homeradar_addons_get_option('map_provider');
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>> 
    <div class="for-hide-on-author"></div>
    <!-- lsingle-block-box --> 
    <div class="lsingle-block-box lmap-box lmap-block">
        <?php if($title != ''): ?>
        <div class="lsingle-block-title">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="lsingle-block-content">
            <div class="map-container map-<?php echo esc_attr( $map_provider );?>-container">
                <?php 
                $sinit_map = $map_provider == 'osm' ? 'yes' : homeradar_addons_get_option('single_map_init', 'no');
                if( $sinit_map != 'yes' ): $sinit_map = 'no'; ?>
                    <div class="singleMap-init-wrap mb-20"><a href="#" class="btn color2-bg initSingleMap"><?php echo esc_html_x( 'View Map', 'Single listing', 'homeradar-add-ons' ); ?><i class="fal fa-map"></i></a></div>
                <?php endif; ?>
                <div id="<?php echo uniqid('singleMap'); ?>" 
                    class="singleMap singleMap-<?php echo esc_attr( $map_provider );?> singleMap-init-<?php echo $sinit_map;?>" 
                    data-lat="<?php echo esc_attr( $latitude );?>" 
                    data-lng="<?php echo esc_attr( $longitude );?>" 
                    data-loc="<?php echo esc_attr( $address );?>" 
                    data-zoom="<?php echo homeradar_addons_get_option('gmap_single_zoom');?>"  
                    data-exmarker="<?php echo esc_url( homeradar_addons_get_attachment_thumb_link( homeradar_addons_get_listing_marker( get_the_ID() ) ) ); ?>"
                    ></div>


                
            </div>

        </div><!-- lsingle-block-content end -->  
    </div><!-- lsingle-block-box end -->  
</div>
<?php endif; 

endif;// check hide on plans