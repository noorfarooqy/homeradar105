<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $taxes = $max_level = $hide_empty = $width = $placeholder = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'filter_status',
    'azp-element-' . $azp_mID,
    'filter-gid-item', 
    'filter-gid-wid-' . $width,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
$listing_taxes = homeradar_addons_filter_cats($taxes, 0, $hide_empty, 'listing_status');
$search_taxes = '';
if(is_tax('listing_status')){
    $termObj = get_term( get_queried_object_id(), 'listing_status' );
    if ( ! empty( $termObj ) && ! is_wp_error( $termObj ) ){
        // $search_taxes = array( $termObj->slug );
        $search_taxes = $termObj->slug;
    }
}else{
    if( isset($_GET['status']) ){
        $search_taxes = $_GET['status'];
    }
    // if(isset($_GET['status'])&&is_array($_GET['status'])){
    //     $search_taxes = array_filter($_GET['status']);
    //     $search_taxes = array_map('esc_attr', $search_taxes);
    // } 
}
                    
?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>
    <div class="filter-item-inner">
        <select data-placeholder="<?php echo esc_attr($placeholder); ?>"  class="chosen-select" name="status">
            <?php if(!empty($placeholder)): ?><option value=""><?php echo esc_attr($placeholder); ?></option><?php endif; ?>
            <?php 
            foreach ($listing_taxes as $tax) {
                // if(in_array($tax['slug'], $search_taxes)){
                //     echo '<option value="'.$tax['slug'].'" selected>'.str_repeat('-', $tax['level']).$tax['name'].'</option>';
                // }else{
                //     echo '<option value="'.$tax['slug'].'">'.str_repeat('-', $tax['level']).$tax['name'].'</option>';
                // }
                echo '<option value="'.$tax['slug'].'" '.selected( $search_taxes, $tax['slug'],false).'>'.str_repeat('-', $tax['level']) .$tax['name'].'</option>';
            }
            ?>
        </select>
    </div>
</div>
