<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $taxes = $max_level = $hide_empty = $width = $placeholder = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'filter_status_btn',
    'azp-element-' . $azp_mID,
    'filter-gid-item', 
    'filter-gid-wid-' . $width,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
$listing_taxes = homeradar_addons_filter_cats($taxes, 0, $hide_empty, 'listing_status');
if( empty($listing_taxes) ) return;
$search_taxes = '';
if(is_tax('listing_status')){
    $termObj = get_term( get_queried_object_id(), 'listing_status' );
    if ( ! empty( $termObj ) && ! is_wp_error( $termObj ) ){
        $search_taxes = $termObj->slug;
    }
}elseif( isset($_GET['status']) ){
    if( is_array($_GET['status']) ){
        $search_taxes = array_filter($_GET['status']);
        $search_taxes = array_map('esc_attr', $search_taxes);
        $search_taxes = reset($search_taxes);   
    }else{
        $search_taxes = $_GET['status'];
    }
}
              
?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>
    <div class="filter-item-inner">
        <div class="custom-switcher fl-wrap">
            <div class="fieldset fl-wrap">
                <?php 
                $hasVal = in_array($search_taxes, array_column($listing_taxes, 'slug') );
                foreach ($listing_taxes as $key => $tax) {
                    $uqid = uniqid();
                    if( $hasVal ): ?>
                    <input type="radio" name="status" id="<?php echo esc_attr( $uqid ); ?>" value="<?php echo esc_attr( $tax['slug'] ); ?>" class="tariff-toggle" <?php checked( $search_taxes, $tax['slug'],true);?>>
                    <?php else: ?>
                    <input type="radio" name="status" id="<?php echo esc_attr( $uqid ); ?>" value="<?php echo esc_attr( $tax['slug'] ); ?>" class="tariff-toggle" <?php checked( $key, 0,true);?>>
                    <?php endif; ?>
                    <label for="<?php echo esc_attr( $uqid ); ?>"><?php echo esc_html( $tax['name'] ); ?></label>
                    <?php
                }
                ?>
                <span class="switch color-bg"></span>
            </div>
        </div>
    </div>
</div>
