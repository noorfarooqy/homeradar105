<?php 

$socials = homeradar_addons_get_socials_list();
?>
<div class="tab-item-content hidden">
    <div class="mtbox-fields-wrap dis-flex flx-wrap">
        
        <?php
        foreach ($socials as $val => $lbl) {
            ?>
            <div class="mtbox-field submit-field-6">
                <label for="<?php echo $val; ?>" class="lbl-block"><?php echo sprintf( __( '%s URL', 'homeradar-add-ons' ), $lbl ); ?></label>
                <input type="text" class="input-text full-w" name="<?php echo $val; ?>" id="<?php echo $val; ?>" value="<?php echo get_post_meta( $post->ID, ESB_META_PREFIX.$val, true );?>">
            </div>
            <?php
        }
        ?>
        
    </div>
</div>

