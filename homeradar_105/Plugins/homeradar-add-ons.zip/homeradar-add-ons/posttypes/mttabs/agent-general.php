<?php 

?>
<div class="tab-item-content">
    <div class="mtbox-fields-wrap dis-flex flx-wrap">
        <?php 
        $value = get_post_meta( $post->ID, ESB_META_PREFIX.'coverImage', true ); 
        $imgField = 'coverImage';
        ?>
        <div class="mtbox-field submit-field-12">
            <label class="lbl-block"><?php _e( 'Cover Image', 'homeradar-add-ons' ); ?></label>
            <?php 
                echo '<div class="form-field media-field-wrap">';

                    echo '<img class="'. $imgField .'_preview" src="'.(isset($value['url']) ? esc_attr($value['url']) : '').'" alt="" '.(isset($value['url']) ? ' style="display:block;width:200px;height=auto;margin-bottom:10px;"' : ' style="display:none;width:200px;height=auto;margin-bottom:10px;"').'>';
                    echo '<input type="hidden" name="'. $imgField .'[url]" class="'. $imgField .'_url" value="'.(isset($value['url']) ? esc_attr($value['url']) : '').'">';
                    echo '<input type="hidden" name="'. $imgField .'[id]" class="'. $imgField .'_id" value="'.(isset($value['id']) ? esc_attr($value['id']) : '').'">';
                    
                    echo '<p class="description" style="margin-bottom:0;"><a href="#" data-uploader_title="'.esc_html__( 'Select Image', 'homeradar-add-ons' ).'" class="button button-primary upload_image_button metakey-'.$imgField.' fieldkey-'.''.'">'.esc_html__('Upload Image', 'homeradar-add-ons').'</a>  <a href="#" class="button button-secondary remove_image_button metakey-'.$imgField.' fieldkey-'.''.'">'.esc_html__('Remove', 'homeradar-add-ons').'</a></p>';

                echo '</div>';
            ?>
        </div>
        


    	<!-- <div class="mtbox-field submit-field-12">
            <label for="short-desc" class="lbl-block"><?php _e( 'Short Description', 'homeradar-add-ons' ); ?></label>
            <textarea name="short_desc" id="short-desc" class="input-text full-w" cols="30" rows="3"><?php // echo $post->post_excerpt; ?></textarea>
        </div> -->

        <div class="mtbox-field submit-field-12">
            <label for="areas" class="lbl-block"><?php _e( 'Service Areas', 'homeradar-add-ons' ); ?></label>
            <input type="text" class="input-text full-w" name="areas" id="areas" value="<?php echo get_post_meta( $post->ID, ESB_META_PREFIX.'areas', true );?>">
            <p><?php _e( 'Enter the agent service areas. Separate by comma (,)', 'homeradar-add-ons' ); ?></p>
        </div>

        <div class="mtbox-field submit-field-12">
            <label for="specialties" class="lbl-block"><?php _e( 'Specialties', 'homeradar-add-ons' ); ?></label>
            <input type="text" class="input-text full-w" name="specialties" id="specialties" value="<?php echo get_post_meta( $post->ID, ESB_META_PREFIX.'specialties', true );?>">
            <p><?php _e( 'Enter the agent specialties. Separate by comma (,)', 'homeradar-add-ons' ); ?></p>
        </div>

        <?php
        foreach ($generalFields as $field) {
        	$id = uniqid('mtfield');
            ?>
            <div class="mtbox-field submit-field-6">
                <label for="<?php echo $id; ?>" class="lbl-block"><?php echo $field['label']; ?></label>
                <input type="text" class="input-text full-w" name="<?php echo $field['name']; ?>" id="<?php echo $id; ?>" value="<?php echo get_post_meta( $post->ID, ESB_META_PREFIX.$field['name'], true );?>">
            </div>
            <?php
        }
        ?>
        <div class="mtbox-field submit-field-12">
            <hr/>
        </div>
        
        <div class="mtbox-field submit-field-12">
            <label for="agency" class="lbl-block"><?php _e( 'Agency', 'homeradar-add-ons' ); ?></label>
            <?php 
                $posts = get_posts( array(
                    'post_type'         => 'lagency',
                    'posts_per_page'    => -1,
                    'post_status'       => 'publish',
                    'fields'            => 'ids',
                ));
                $selected = get_post_meta( $post->ID, ESB_META_PREFIX.'agency', true );
                echo '<select id="agency" name="agency" class="full-w">';
                    echo '<option value="">'.__( 'None', 'homeradar-add-ons' ).'</option>';
                foreach ($posts as $key => $lid) {
                    
                    echo '<option value="'.$lid.'" '.selected( $selected, $lid, false ).'>'.get_the_title($lid).'</option>';
                    
                }
                echo '</select>';

            ?>
        </div>
            

    </div>
</div>