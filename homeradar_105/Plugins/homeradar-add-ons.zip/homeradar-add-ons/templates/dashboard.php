<?php
/* add_ons_php */
$dashboard = get_query_var('dashboard');
// $current_user = wp_get_current_user();
// homeradar_addons_get_template_part('template-parts/dashboard/headsec');
?>
<!--  section  -->
<section class="gray-bg main-dashboard-sec" id="sec1">
    <div class="main-dashboard-container">
        <!-- dashbard-menu-wrap --> 
        <div class="dashbard-menu-overlay"></div>
        <div class="dashbard-menu-wrap">
            <div class="dashbard-menu-close"><i class="fal fa-times"></i></div>
            <div class="dashbard-menu-container">
                <?php homeradar_addons_get_template_part('template-parts/dashboard/sidebar');?>
            </div>
            <div class="dashbard-menu-footer"><div class="copyright small-ftcopyright"></div></div>
        </div>
        <!-- dashbard-menu-wrap end  -->        
        <!-- content -->    
        <div class="dashboard-content">
            <div class="dashboard-menu-btn color-bg"><span><i class="fas fa-bars"></i></span><?php _ex( 'Dasboard Menu', 'Dasboard', 'homeradar-add-ons' ); ?></div>
            <div class="container dasboard-container">
                <!-- dashboard-title -->    
                <div class="dashboard-title fl-wrap fleft">
                    <div class="dashboard-title-item"><span><?php echo Esb_Class_Dashboard::screen_title(); ?></span></div>
                    <?php homeradar_addons_get_template_part('template-parts/dashboard/top-infos'); ?>                            
                </div>
                <div class="clearfix"></div>
                <!-- dashboard-title end -->        
                <div class="dasboard-wrapper fl-wrap no-pag">
                    <div class="dashboard-main-col">
                        <?php
                        do_action( 'cth_listing_dashboard_content_before', $dashboard );
                        $skipDashboard = apply_filters( 'cth_listing_dashboard_skip_content', $dashboard );
                        if( $skipDashboard !== false ){
                            switch ($dashboard) {
                                case 'changepass':
                                    homeradar_addons_get_template_part('template-parts/dashboard/changepass');
                                    break;
                                case 'packages':
                                    if (homeradar_addons_get_option('db_hide_packages') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/packages');
                                    }

                                    break;
                                case 'ads':
                                    if (homeradar_addons_get_option('db_hide_ads') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/ads');
                                    }

                                    break;
                                case 'invoices':
                                    if (homeradar_addons_get_option('db_hide_invoices') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/invoices');
                                    }

                                    break;
                                case 'listings':
                                    homeradar_addons_get_template_part('template-parts/dashboard/listings');
                                    break;

                                    
                                case 'products':
                                    if (homeradar_addons_get_option('db_hide_products') != 'yes') {
                                        $product_id = isset($_GET['edit']) && !empty( $_GET['edit'] ) ? abs($_GET['edit']) : 0; 
                                        if( !empty($product_id) && get_post_type( $product_id) == 'product' && get_post_field( 'post_author', $product_id, 'display' ) == get_current_user_id()  ){
                                            homeradar_addons_get_template_part('template-parts/dashboard/product','edit', array('product_id'=>$product_id));
                                        }else{
                                            homeradar_addons_get_template_part('template-parts/dashboard/products');
                                        }
                                    }

                                    break;
                                case 'reviews':
                                    if (homeradar_addons_get_option('db_hide_reviews') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/reviews');
                                    }

                                    break;
                                case 'chats':
                                    if (homeradar_addons_get_option('admin_chat') == 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/chats');
                                    }

                                    break;
                                case 'messages':
                                    if (homeradar_addons_get_option('db_hide_messages') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/messages');
                                    }

                                    break;
                                case 'bookings':
                                    if (homeradar_addons_get_option('db_hide_bookings') != 'yes') {
                                        $pid = isset($_GET['bkid']) && !empty( $_GET['bkid'] ) ? abs($_GET['bkid']) : 0; 
                                        if( !empty($pid) && get_post_type( $pid) == 'lbooking' ){
                                            homeradar_addons_get_template_part('template-parts/dashboard/booking','',array('pid'=>$pid));
                                        }else{
                                            homeradar_addons_get_template_part('template-parts/dashboard/bookings');
                                        }

                                        
                                    }

                                    break;
                                case 'inquiries':
                                    if (homeradar_addons_get_option('db_show_inquiries') == 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/inquiries');
                                    }

                                    break;
                                case 'wooorders':
                                    if (homeradar_addons_get_option('db_show_woo_orders') == 'yes') {
                                        if( isset($_GET['view_order']) && !empty( $_GET['view_order'] ) ){
                                            homeradar_addons_get_template_part('template-parts/dashboard/wooorder');
                                        }else{
                                            homeradar_addons_get_template_part('template-parts/dashboard/wooorders');
                                        }
                                        
                                    }

                                    break;
                                case 'bookmarks':
                                    if (homeradar_addons_get_option('db_hide_bookmarks') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/bookmarks');
                                    }

                                    break;
                                case 'withdrawals':
                                    if (homeradar_addons_get_option('db_hide_withdrawals') != 'yes') {
                                        homeradar_addons_get_template_part('template-parts/dashboard/withdrawal');
                                    }

                                    break;
                                case 'profile':
                                    homeradar_addons_get_template_part('template-parts/dashboard/profile');
                                    break;
                                case 'feed':
                                    if( Esb_Class_Membership::is_author() ) 
                                        homeradar_addons_get_template_part('template-parts/dashboard/feed');
                                    break;
                                case 'ical':
                                    if( Esb_Class_Membership::is_author() && homeradar_addons_get_option('db_hide_ical') != 'yes' ) 
                                        homeradar_addons_get_template_part('template-parts/dashboard/ical');
                                    break;
                                case 'agents':
                                    $agent = isset($_GET['agent']) && !empty( $_GET['agent'] ) ? abs($_GET['agent']) : 0; 
                                    if( !empty($agent) && get_post_type( $agent) == 'lagent' ){
                                        homeradar_addons_get_template_part('template-parts/dashboard/agent','edit',array('agent'=>$agent));
                                    // }elseif(isset($_GET['new']) && !empty( $_GET['new'] )){
                                    //     homeradar_addons_get_template_part('template-parts/dashboard/agent', 'new');
                                    }else{
                                        homeradar_addons_get_template_part('template-parts/dashboard/agents');
                                    }
                                    break;
                                default:
                                    if( Esb_Class_Membership::is_author() == false )
                                        homeradar_addons_get_template_part('template-parts/dashboard/feed');
                                    else
                                        homeradar_addons_get_template_part('template-parts/dashboard/dashboard');
                                    break;

                            }
                        }
                        do_action( 'cth_listing_dashboard_content_switch', $dashboard );
                        ?>
                    </div>
                    <!-- dashboard-main-col end-->

                    
                </div>
            </div>
            <?php homeradar_addons_get_template_part('template-parts/dashboard/footer'); ?>
                         
        </div>
        <!-- content end -->    
        <div class="dashbard-bg gray-bg"></div>
    </div>
    <!-- end main-dashboard-container -->
    
</section>
<!--  section  end-->
<div class="limit-box"></div>
<div class="clearfix"></div>
<?php
// add_filter( 'cth_listing_dashboard_skip_content', function($dashboard){
//     if( $dashboard == 'YOUR_DASHBOARD_SLUG' ) 
//         return false;
//     return $dashboard;
// } );
// add_action( 'cth_listing_dashboard_content_switch', function($dashboard){
//     if( $dashboard == 'YOUR_DASHBOARD_SLUG' ) {
//         echo get_the_content(null, false, 1000); // 1000 is your page id
//     }
// } );

