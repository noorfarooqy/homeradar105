<?php
/* add_ons_php */
// $current_user = wp_get_current_user();
// homeradar_addons_get_template_part('template-parts/dashboard/headsec');
?>
<!--  section  -->
<section class="gray-bg main-dashboard-sec" id="sec1">
    <div class="main-dashboard-container">
        <!-- dashbard-menu-wrap --> 
        <div class="dashbard-menu-overlay"></div>
        <div class="dashbard-menu-wrap">
            <div class="dashbard-menu-close"><i class="fal fa-times"></i></div>
            <div class="dashbard-menu-container">
                <?php homeradar_addons_get_template_part('template-parts/dashboard/sidebar', '', array('is_add_page'=>true) );?>
            </div>
            <div class="dashbard-menu-footer"><div class="copyright small-ftcopyright"></div></div>
        </div>
        <!-- dashbard-menu-wrap end  -->        
        <!-- content -->    
        <div class="dashboard-content">
            <div class="dashboard-menu-btn color-bg"><span><i class="fas fa-bars"></i></span><?php _ex( 'Dasboard Menu', 'Dasboard', 'homeradar-add-ons' ); ?></div>
            <div class="container dasboard-container">
                <!-- dashboard-title -->    
                <div class="dashboard-title fl-wrap fleft">
                    <div class="dashboard-title-item"><span><?php _ex( 'Add Listing', 'Dashboard', 'homeradar-add-ons' ); ?></span></div>
                    <?php homeradar_addons_get_template_part('template-parts/dashboard/top-infos'); ?>                     
                </div>
                <div class="clearfix"></div>
                <!-- dashboard-title end -->        
                <div class="dasboard-wrapper fl-wrap no-pag">
                    <div class="dashboard-main-col">
                        
                        <div id="submit-listing-view" class="submit-listing-view">
                        <!-- #submit-listing-view -->
                            <div id="submit-listing-message"></div>
                            
                            <div id="ladd-app" class="submit-fields-dflex"></div>
                        </div>
                        <!-- #submit-listing-view -->

                    </div>
                    <!-- dashboard-main-col end-->

                    
                </div>
            </div>
            <?php homeradar_addons_get_template_part('template-parts/dashboard/footer'); ?>             
        </div>
        <!-- content end -->    
        <div class="dashbard-bg gray-bg"></div>
    </div>
    <!-- end main-dashboard-container -->
    
</section>
<!--  section  end-->
<div class="limit-box"></div>
<div class="clearfix"></div>
<?php if( homeradar_addons_get_option('subm_subtitle') == 'yes' ): ?>
<script type="text/template" id="tmpl-submit-sub-heading">
    <h4><?php _ex( 'This is sub heading for submit listing page', 'Submit listing', 'homeradar-add-ons' );?></h4>
</script>
<?php endif; ?>
<script type="text/template" id="tmpl-submit-must-ltype">
    <h4><?php _ex( 'You must select a listing type to add listing to', 'Submit listing', 'homeradar-add-ons' );?></h4>
</script>
