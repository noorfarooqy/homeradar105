<?php
/* add_ons_php */
global $wp_query;
// echo '<pre>';
// var_dump($wp_query);
// global $query_string;
// echo '<pre>';
// var_dump($query_string);
// wp_parse_str( $query_string, $search_query );
// // $search = new WP_Query( $search_query );

// var_dump($search_query);
if(!isset($card_layout)) $card_layout = homeradar_addons_get_option('listings_grid_layout');

do_action( 'homeradar_addons_listings_loop_before'); 

?>
<div class="listing-item-container init-grid-items" id="lisconfw">
<div id="listing-items" class="listing-items listing-items-wrapper">
<?php
$action_args = array(
    'listings' => array()
);
// https://codex.wordpress.org/Function_Reference/do_action_ref_array
do_action_ref_array( 'homeradar_addons_listing_loop_before', array(&$action_args) );

if ( have_posts() ) :
    /* Start the Loop */
    while ( have_posts() ) : the_post();
        homeradar_addons_get_template_part('template-parts/listing', '', array('card_layout'=>$card_layout));
        // $action_args['listings'][] = get_the_ID();
    endwhile;
elseif(empty($action_args['listings'])):
    homeradar_addons_get_template_part('template-parts/search-no');
endif;
?>
</div>
<div class="listings-pagination-wrap">
	<?php
    // echo $wp_query->found_posts;
	homeradar_addons_ajax_pagination();
	// homeradar_addons_pagination();
	// echo '<div><a class="load-more-button" href="#">Load more <i class="fa fa-circle-o-notch"></i> </a></div>';
	?>
</div>
<?php $found_posts = $wp_query->found_posts + count($action_args['listings']); ?>
<div class="lresults-data" style="display:none;"><?php echo intval($found_posts); ?></div>
</div>
<?php
// end if has_posts
// wp_localize_script( 'homeradar-addons', '_homeradar_add_ons_locs', $action_args['gmap_listings']);
        
do_action( 'homeradar_addons_listings_loop_after'); 
