<?php
/* add_ons_php */

get_header(  ); 
$css_classes = array(
    'listings-grid-wrap clearfix',
    homeradar_addons_get_option('columns_grid').'-cols',
    'template-full-map'
);

$css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

?>
<div class="<?php echo esc_attr( $css_class );?>">
    
    
    <!-- Map -->
    <div class="map-container fw-map big_map top-pos-map">
        <?php homeradar_addons_get_template_part('template-parts/filter/map'); ?>
    </div>
    <!-- Map end -->    
    <!-- breadcrumbs-->
    <div class="breadcrumbs-wrapper inline-breadcrumbs fw-breadcrumbs sp-brd fl-wrap">
        <div class="container">
            <div class="inline-breadcrumbs-wrap flex-items-center jtf-space-between flw-wrap">
                <?php if( function_exists('homeradar_get_template_part') ) homeradar_get_template_part( 'template-parts/breadcrumbs', '', array( 'is_top'=>false) ); ?>
                <div class="inline-breadcrumbs-right flex-items-center">
                    
                    <?php homeradar_addons_get_template_part( 'template-parts/filter/categories', '', array('exclass' => 'inline-categories') ); ?>
                    <?php homeradar_addons_echo_socials_share(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumbs end -->

    <section class="gray-bg small-padding ">
        <div class="container">
            <div class="mob-nav-content-btn  color-bg show-list-wrap-search ntm fl-wrap"><?php echo esc_html_x( 'Show  Filters', 'Filter', 'homeradar-add-ons' ); ?></div>
            <!-- list-searh-input-wrap-->
            <div class="list-searh-input-wrap box_list-searh-input-wrap lws_mobile fl-wrap">
                <?php homeradar_addons_get_template_part( 'templates/filter_form' ); ?>
            </div>
            <!-- list-searh-input-wrap end-->                           
            <?php homeradar_addons_get_template_part( 'template-parts/filter/head' ); ?>                 
            <!-- list-main-wrap-->
            <div class="list-main-wrap fl-wrap card-listing listings-full-map">
                
                <?php 
                if( is_singular('page') ) // custom template for page
                    homeradar_addons_get_template_part('templates/loop','custom'); 
                else
                    homeradar_addons_get_template_part('templates/loop'); 
                ?>
                
            </div><!-- list-main-wrap end-->
                                
        </div><!-- container end -->
    </section>

    
</div>
<!--template wrap end -->
<div class="limit-box"></div>
<div class="clearfix"></div>
<?php

get_footer(  );