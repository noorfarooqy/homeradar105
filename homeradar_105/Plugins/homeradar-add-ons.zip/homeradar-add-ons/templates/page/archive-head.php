<?php
/* add_ons_php */

if( homeradar_addons_get_option('show_lheader') == 'yes' ) :
    $header_bg = homeradar_addons_get_option('lheader_bg');
    if(!empty($header_bg) && isset($header_bg['id'])) $header_bg = $header_bg['id'];
?>
<!--  section  -->
<section class="parallax-section single-par color-bg">
    <div class="container idx-5">
        <div class="section-title center-align big-title">
            <h2 class="post-head-title"><span><?php echo homeradar_addons_get_option('lheader_title'); ?></span></h2>
            <?php echo homeradar_addons_get_option('lheader_intro'); ?>
        </div>
    </div>
    <div class="pwh_bg bg" data-bg="<?php echo esc_url( homeradar_addons_get_attachment_thumb_link( $header_bg, 'full') );?>"></div>
    <div class="mrb_pin vis_mr mrb_pin3 "></div>
    <div class="mrb_pin vis_mr mrb_pin4 "></div>
</section>
<!--  section  end-->
<?php endif;