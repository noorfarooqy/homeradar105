<?php
/* add_ons_php */
get_header( 'nonav' ); 
?>
<div class="log-reg-cols-wrap">
    <?php 
    while ( have_posts() ) : the_post(); ?>
    <!--login-column  -->
    <div class="login-column">
        <div class="login-column_header">
            <?php 
            if( has_custom_logo() ){
                the_custom_logo(); 
            }else echo '<a class="custom-logo-link logo-text" href="'.esc_url( home_url('/' ) ).'"><h2>'.get_bloginfo( 'name' ).'</h2></a>'; 
            ?>
            <div class="clearfix"></div>
            <h4>Welcome to Login system.</h4>
        </div>
        <div class="login-column-inner">
            <?php
            // while ( have_posts() ) : the_post();

                the_content();

            // endwhile; // End of the loop.
            ?>
        </div>
    </div>
    <!--login-column end-->
    <!--login-column-bg  -->
    <div class="login-column-bg gradient-bg">
    <?php 
    // Get the list of files
    $files = get_post_meta( get_the_ID(), '_cth_log_reg_bg', true );
    if( !empty($files) ):

    ?>
        <div class="half-hero-bg-media full-height">
             
            <div class="slider-progress-bar">
                <span>
                    <svg class="circ" width="30" height="30">
                        <circle class="circ2" cx="15" cy="15" r="13" stroke="rgba(255,255,255,0.4)" stroke-width="1" fill="none"/>
                        <circle class="circ1" cx="15" cy="15" r="13" stroke="#fff" stroke-width="2" fill="none"/>
                    </svg>
                </span>
            </div>
            <div class="slideshow-container" >
                <?php 
                foreach ( (array) $files as $attachment_id => $attachment_url ) { ?>
                    <!-- slideshow-item -->
                    <div class="slideshow-item">
                        <div class="bg" data-bg="<?php echo esc_url( homeradar_addons_get_attachment_thumb_link($attachment_id, 'full') ); ?>"></div>
                        <div class="overlay"></div>
                    </div>
                    <!--  slideshow-item end  -->
                    <?php
                }
                ?>
            </div>
        </div>   
    <?php endif; ?>
        <div class="login-promo-container">
            <div class="container">
                <?php echo do_shortcode( get_post_meta(get_the_ID(),'_cth_log_reg_right',true ) ); ?>
            </div>
        </div>
    </div>
    <!--login-column-bg end-->
    <?php endwhile; // End of the loop. ?>
</div>
<!--log-reg-cols-wrap end -->
<?php

get_footer( 'nocopyright' );