<?php
/* add_ons_php */
?>
<script type="text/template" id="tmpl-load-listings">
    <div class="listings-loader">
        <div class="lload-icon-wrap">
            <i class="fal fa-spinner fa-pulse fa-3x"></i>
        </div>
        <div class="lload-text-wrap"><?php esc_html_e('Loading', 'homeradar-add-ons');?></div>
    </div>
</script>

<script type="text/template" id="tmpl-no-results">
    <?php homeradar_addons_get_template_part('template-parts/search-no');?>
</script>
<script type="text/template" id="tmpl-map-info">

    <div class="map-popup-wrap">
        <div class="map-popup">
            {{{data.lstatus}}}{{{data.cat}}}
            <div class="infoBox-close"><i class="fal fa-times"></i></div> 
            <a href="{{data.url}}" class="listing-img-content" style="background-image: url({{data.thumbnail}})"></a> 
            <div class="listing-content">  
                <div class="listing-title">   
                    <h4><a href="{{data.url}}">{{{data.title}}}</a></h4>
                    <# if(data.address){ #><span class="map-popup-location-info">{{{data.address}}}</span><# } #>
                </div>
                <span class="map-popup-price fl-wrap">{{{data.price}}}</span>
            </div>    
        </div>
    </div>

    
    


</script>

<script type="text/template" id="tmpl-feature-search">
<# _.each(data.features, function(fea){ #>
<?php homeradar_addons_get_template_part('templates-inner/feature-search');?>
<# }) #>
</script>
<script type="text/template" id="tmpl-filter-subcats">
<# _.each(data.subcats, function(subcat){ #>
<?php homeradar_addons_get_template_part('templates-inner/subcats-filter');?>
<# }) #>
</script>
<div id="ol-popup" class="ol-popup">
    <a href="#" id="ol-popup-closer" class="ol-popup-closer"></a>
    <div id="ol-popup-content"></div>
</div>
