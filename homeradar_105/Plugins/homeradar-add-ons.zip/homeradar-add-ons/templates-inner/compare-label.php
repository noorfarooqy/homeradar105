<?php
/* add_ons_php */
?>
<ul class="no-list-style">
    <li class="compare-price"><?php _ex( 'Price', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-beds"><?php _ex( 'Bedrooms', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-baths"><?php _ex( 'Bathrooms', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-garage"><?php _ex( 'Garages', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-area"><?php _ex( 'Area', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-kitchens"><?php _ex( 'Kitchens', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-livingrooms"><?php _ex( 'Livingrooms', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-building-age"><?php _ex( 'Building Age', 'Compare Label', 'homeradar-add-ons' ); ?></li>
    <li class="compare-floors"><?php _ex( 'Floors', 'Compare Label', 'homeradar-add-ons' ); ?></li>
</ul>