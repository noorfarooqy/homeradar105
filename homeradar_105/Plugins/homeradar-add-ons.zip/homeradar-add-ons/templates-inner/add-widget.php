<?php
/* add_ons_php */
$widget_positions = array(
	'0' => __( 'First Position', 'homeradar-add-ons' ),
	'1' => __( 'Second Position', 'homeradar-add-ons' ),
	'2' => __( 'Third Position', 'homeradar-add-ons' ),
	'3' => __( 'Fourth Position', 'homeradar-add-ons' ),
	'4' => __( 'Fifth Position', 'homeradar-add-ons' ),
	'5' => __( 'Sixth Position', 'homeradar-add-ons' ),
	'6' => __( 'Seventh Position', 'homeradar-add-ons' ),
	'7' => __( 'Eighth Position', 'homeradar-add-ons' ),
	'8' => __( 'Nineth Position', 'homeradar-add-ons' ),
	'9' => __( 'Tenth Position', 'homeradar-add-ons' ),
	
);
if(!isset($index)) $index = false;
if(!isset($name)) $name = false;
if(!isset($widget)) $widget = array(
	'widget_title'		=>'Widget Title',
	'widget_position'	=>'1',
	'fields'			=>array(

	)
);


$index_text = ($index === false)? '{{data.index}}':$index;
$name_text = ($name == false)? '{{data.field_name}}':$name;
?>
<div class="entry">
    <div class="widget-infos">
    	<input type="text" name="<?php echo $name_text; ?>[<?php echo $index_text;?>][widget_title]" placeholder="<?php esc_attr_e( 'Widget Title',  'homeradar-add-ons' );?>" value="<?php echo isset($widget['widget_title'])? $widget['widget_title'] : '';?>" required>
    	<select  name="<?php echo $name_text; ?>[<?php echo $index_text;?>][widget_position]" required>
        	<option value=""><?php _e( 'Widget Position',  'homeradar-add-ons' );?></option>
	        <?php
	        foreach ($widget_positions as $pos => $lbl) {
	            echo '<option value="'.$pos.'" '.selected( (isset($widget['widget_position'])? $widget['widget_position'] : ''), $pos, false ).'>'.$lbl.'</option>';
	        }
	        ?>
	    </select>
    	<button class="btn rmwidget" type="button" ><span class="dashicons dashicons-trash"></span></button>
    </div>
    <div class="widget-fields">
    	<div class="repeater-fields-wrap"  data-tmpl="tmpl-content-addwidgetfield">
            <div class="repeater-fields">
            <?php 
            if(!empty($widget['fields'])){
                foreach ((array)$widget['fields'] as $key => $field) {
                    homeradar_addons_get_template_part('templates-inner/add-widgetfield',false, array( 'index'=>$key,'name'=>$name.'['.$index.'][fields]','field'=>$field ) );
                }
            }
            ?>
            </div>
            <button class="btn addfield" data-name="<?php echo $name_text; ?>[<?php echo $index_text;?>][fields]" data-parent-index="<?php echo $index_text;?>" type="button"><?php  esc_html_e( 'Add Field','homeradar-add-ons' );?></button>
        </div>
    </div>
    
</div>
<!-- end entry -->

