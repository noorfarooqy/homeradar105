<?php
/* add_ons_php */
if(!isset($photos)) $photos = array();
if(!isset($azp_attrs)) $azp_attrs = array();
$images_size = 'full';
if( !empty($azp_attrs['images_size']) ) $images_size = $azp_attrs['images_size'];
?>
<section class="listing-hero-section hidden-section listing-hslideshow-sec" data-scrollax-parent="true" id="lhead_sec">
	<div class="bg-wrap">
		<?php 
		if(!empty($photos)){ ?>
        <div class="half-hero-bg-media full-height">
            <div class="slider-progress-bar">
                <span>
                    <svg class="circ" width="30" height="30">
                        <circle class="circ2" cx="15" cy="15" r="13" stroke="rgba(255,255,255,0.4)" stroke-width="1" fill="none"/>
                        <circle class="circ1" cx="15" cy="15" r="13" stroke="#fff" stroke-width="2" fill="none"/>
                    </svg>
                </span>
            </div>
            <div class="slideshow-container" >
            	<?php
		            foreach ($photos as $id ) {
	            	$image = get_post($id);
                	if( !$image ) continue;
	            ?>
	            	<!-- slideshow-item -->
                    <div class="slideshow-item">
                        <div class="bg" data-bg="<?php echo wp_get_attachment_image_url( $id, $images_size );?>"></div>
                    </div>
                    <!--  slideshow-item end  -->
	            <?php
	            }
	        	?>
            </div>
        </div>
        <?php 
		} ?>
    </div>
    <div class="container idx-5">
        <?php homeradar_addons_get_template_part( 'template-parts/single/head_infos', '', array('azp_attrs'=>$azp_attrs) ); ?>
    </div>
</section>