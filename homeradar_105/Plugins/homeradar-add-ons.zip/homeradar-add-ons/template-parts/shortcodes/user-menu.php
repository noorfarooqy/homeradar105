<?php
/* add_ons_php */
$umenu_earnings = homeradar_addons_get_option('umenu_earnings');
?>
<div class="show-reg-form dasbdord-submenu-open"><div class="au-avatar"><?php 
            echo get_avatar($current_user->user_email,'80','https://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=80', $current_user->display_name );
        ?></div></div>

<div class="dashboard-submenu header-user-menu user-menu-<?php echo $style;?>">
    <div class="dashboard-submenu-title fl-wrap"><?php echo sprintf(_x( 'Welcome , <span>%s</span>', 'Header', 'homeradar-add-ons' ), $current_user->display_name); ?></div>
    <ul class="head-user-menu">
        <?php if( $umenu_earnings != 'yes' && Esb_Class_Membership::is_author() ): ?>
        <li class="user-menu-details">
            <div class="au-earning">
                <?php if( homeradar_addons_get_option('db_hide_withdrawals') != 'yes' ): ?>
                <a href="<?php echo Esb_Class_Dashboard::screen_url('withdrawals');?>">
                <?php endif; ?>
                    <?php echo sprintf(_x( '<i class="fal fa-search-dollar"></i> Earning: %s', 'Header', 'homeradar-add-ons' ), homeradar_addons_get_price_formated( Esb_Class_Earning::getBalance($current_user->ID) ) ) ;?>
                <?php if( homeradar_addons_get_option('db_hide_withdrawals') != 'yes' ): ?>      
                </a>
                <?php endif; ?>
            </div>
        </li>
        <?php endif; ?>
        <li class="user-menu-dashboard"><a href="<?php echo Esb_Class_Dashboard::screen_url();?>"><?php _ex( '<i class="fal fa-chart-line"></i> Dashboard', 'Header', 'homeradar-add-ons' );?></a></li>
        <li class="user-menu-profile"><a href="<?php echo get_author_posts_url( $current_user->ID );?>"><?php _ex( '<i class="fal fa-user-edit"></i> View profile', 'Header', 'homeradar-add-ons' );?></a></li>


    <?php if( homeradar_addons_current_user_can('view_listings_dashboard') ): ?>
        <li class="user-menu-addlisting"><a href="<?php echo homeradar_addons_add_listing_url();?>"><?php _ex( '<i class="fal fa-file-plus"></i> Add Listing', 'Header', 'homeradar-add-ons' );?></a></li>
        <?php if (homeradar_addons_get_option('db_hide_bookings') != 'yes'): ?>
            <li class="user-menu-bookings"><a href="<?php echo Esb_Class_Dashboard::screen_url('bookings');?>"><?php _ex( '<i class="fal fa-calendar-check"></i> Bookings', 'Header', 'homeradar-add-ons' );?></a></li>
        <?php endif; ?>
        <li class="user-menu-reviews"><a href="<?php echo Esb_Class_Dashboard::screen_url('reviews');?>"><?php _ex( '<i class="fal fa-comments-alt"></i> Reviews', 'Header', 'homeradar-add-ons' );?></a></li>
    <?php else : ?>
        <?php if (homeradar_addons_get_option('db_hide_bookings') != 'yes'): ?>
            <li class="user-menu-bookings"><a href="<?php echo Esb_Class_Dashboard::screen_url('bookings');?>"><?php _ex( '<i class="fal fa-calendar-check"></i> Bookings', 'Header', 'homeradar-add-ons' );?></a></li>
        <?php endif; ?>
        <?php if( homeradar_addons_get_option('admin_chat') == 'yes' ): ?>
            <li class="user-menu-messages"><a href="<?php echo Esb_Class_Dashboard::screen_url('chats');?>"><?php _ex( '<i class="fal fa-comment-dots"></i> Chats', 'Header', 'homeradar-add-ons' );?></a></li>
        <?php endif; ?>
        <?php if( homeradar_addons_get_option('db_hide_messages') != 'yes' ): ?>
            <li class="user-menu-messages"><a href="<?php echo Esb_Class_Dashboard::screen_url('messages');?>"><?php _ex( '<i class="fal fa-envelope"></i> Messages', 'Header', 'homeradar-add-ons' );?></a></li>
        <?php endif; ?>
    <?php endif; ?>
       

    </ul>
    <a href="<?php echo wp_logout_url( homeradar_addons_get_current_url() ); ?>" class="color-bg db_log-out"><?php _ex( '<i class="far fa-power-off"></i> Log Out', 'Header', 'homeradar-add-ons' );?></a>

</div>
