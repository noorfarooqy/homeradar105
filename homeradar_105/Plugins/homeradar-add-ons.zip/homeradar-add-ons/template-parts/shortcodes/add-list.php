<?php
/* add_ons_php */
?>
<!--  add new  btn -->
<div class="add-list_wrap">
<?php
if(is_user_logged_in()) : ?>
    <a href="<?php echo homeradar_addons_add_listing_url();?>" class="add-list color-bg "><?php _ex( '<i class="fal fa-plus"></i> <span>Add Listing</span>','Header', 'homeradar-add-ons' );?></a>
<?php else : 
	$logBtnAttrs = homeradar_addons_get_login_button_attrs( 'addlist', 'current' );
	?>
    <a href="<?php echo esc_url( $logBtnAttrs['url'] );?>" class="add-list color-bg <?php echo esc_attr( $logBtnAttrs['class'] );?>" data-message="<?php echo esc_attr_x( 'You must be logged in to add listings.','Header', 'homeradar-add-ons' ); ?>"><?php _ex( '<i class="fal fa-plus"></i> <span>Add Listing</span>','Header', 'homeradar-add-ons' );?></a>
<?php 
endif;
?>
</div>
<!--  add new  btn end -->
