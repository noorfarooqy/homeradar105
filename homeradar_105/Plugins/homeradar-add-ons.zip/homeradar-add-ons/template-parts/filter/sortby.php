<?php
/* add_ons_php */
?>
<!-- price-opt-->
<div class="price-opt flex-items-center">
    <span class="price-opt-title"><?php _e( 'Sort by:', 'homeradar-add-ons' ); ?></span>
    <div class="listsearch-input-item">
        <select id="lfilter-orderby" data-placeholder="<?php esc_attr_e( 'Popularity', 'homeradar-add-ons' ); ?>" class="chosen-select no-search-select" name="morderby">
            <option value=""><?php esc_html_e( 'Default',  'homeradar-add-ons' );?></option>
            <option value="most_viewed"><?php esc_html_e( 'Popularity',  'homeradar-add-ons' );?></option>
            <option value="most_liked"><?php esc_html_e( 'Most Liked',  'homeradar-add-ons' );?></option>
            <option value="highest_rated"><?php esc_html_e( 'Most Rated',  'homeradar-add-ons' );?></option>
            <option value="price_low"><?php esc_html_e( 'Price: low to high',  'homeradar-add-ons' );?></option>
            <option value="price_high"><?php esc_html_e( 'Price: high to low',  'homeradar-add-ons' );?></option>
        </select>
        
    </div>
</div>
<!-- price-opt end-->