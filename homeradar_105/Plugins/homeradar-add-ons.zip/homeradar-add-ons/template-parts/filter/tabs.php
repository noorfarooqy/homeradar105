<?php
/* add_ons_php */
?>
		<ul class="tabs-menu fl-wrap no-list-style filter-tabs-menu filter-tabs-menu-pages">
            <li class="current tabs-menu-filterform"><a href="#filters-search"><?php _e( '<i class="fal fa-sliders-h"></i> Filters', 'homeradar-add-ons' ); ?></a></li>
            <?php if( homeradar_addons_get_option('hide_cats_tab') != 'yes' ): ?>
            <li class="tabs-menu-cats"><a href="#category-search"><?php _e( '<i class="fal fa-image"></i>Categories', 'homeradar-add-ons' ); ?></a></li>
        	<?php endif; ?>
        </ul>