<?php
/* add_ons_php */
// $title = post_type_archive_title('', false);
$title = '';
if( is_tax('listing_cat') || is_tax('listing_feature') || is_tax('listing_location') || is_tax('listing_tag') ) 
    $title =  single_term_title( '', false );
if( isset($_GET['search_term']) && $_GET['search_term'] != '' ) 
    $title = stripslashes(esc_html($_GET['search_term']));

if( empty($title) ){
    if( !empty($_GET['lcats']) ){
        if( is_array($_GET['lcats']) ){
            $cat_id = reset($_GET['lcats']);
        }else{
            $cat_id = $_GET['lcats'];
        }
        if( !empty($cat_id) ){
            $cat_term = get_term( (int)$cat_id, 'listing_cat' );
            if ( ! empty( $cat_term ) && ! is_wp_error( $cat_term ) ){
                $title = $cat_term->name;
            }
        }
    }
}

if( empty($title) ) $title = _x( 'Listings', 'Filter title', 'homeradar-add-ons' );

$title = apply_filters( 'cth_search_results_text', $title );

if(!isset($is_fixed)) $is_fixed = true;
if(!isset($side_filter)) $side_filter = true;
// $dynamiccls = 'shsb_btn shsb_btn_act show-list-wrap-search_x';
// if($side_filter) $dynamiccls = 'shsb_btn_x shsb_btn_act_x show-list-wrap-search';
if(!isset($hide_tax_desc)) $hide_tax_desc = false;

?>
<!-- list-main-wrap-header-->
<div class="list-main-wrap-header<?php echo $is_fixed == true ? ' fixed-listing-header': ' static-listing-header'; ?>">
    <div class="container">
            
        <div class="row">
            <div class="col-md-12 flex-items-center jtf-space-between list-main-head-inner">
                <!-- list-main-wrap-title-->
                <div class="list-main-wrap-title">
                    <h2><?php printf( esc_html_x( 'Results for: %s', 'Filter', 'homeradar-add-ons' ), '<span>' . $title . '</span>' ); ?><strong class="lresults-counter"></strong></h2>
                </div>
                <!-- list-main-wrap-title end-->
                <!-- list-main-wrap-opt-->
                <div class="list-main-wrap-opt flex-items-center">
                    <?php if( homeradar_addons_get_option('filter_hide_sortby') != 'yes' ) homeradar_addons_get_template_part('template-parts/filter/sortby'); ?>
                    <?php homeradar_addons_get_template_part('template-parts/filter/grid-list'); ?>
                </div>
                <!-- list-main-wrap-opt end-->

            </div>
            <?php if( false == $hide_tax_desc ): ?>
            <div class="col-md-12 ltax-desc-wrap"><div class="listings_tax_desc listings-tax-column"><?php echo term_description( ); ?></div></div>
            <?php endif; ?>
        </div>   
                         
    </div>
</div>
<!-- list-main-wrap-header end-->   
