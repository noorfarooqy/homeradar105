<?php
/* add_ons_php */
?>
<div class="dasboard-widget-title dbt-mm fl-wrap">
    <h5><i class="fas fa-key"></i><?php _ex( 'Change Password', 'Dashboard', 'homeradar-add-ons' ); ?></h5>
</div>
<!-- profile-edit-container--> 
<div class="dasboard-widget-box">
    <form id="user-changepass-form" action="#" method="POST">
        <div class="ajax-result-message"></div>
        <div class="custom-form">
            <div class="pass-input-wrap fl-wrap hasIcon mb-20">
                <label><?php esc_html_e( 'Current Password', 'homeradar-add-ons' );?><span class="dec-icon"><i class="far fa-lock-open-alt"></i></span></label>
                <div class="pos-relative">
                    <input type="password" name="old_pass" class="pass-input" required="required">
                    <span class="eye"><i class="far fa-eye" aria-hidden="true"></i> </span>
                </div>
            </div>
            <div class="pass-input-wrap fl-wrap hasIcon mb-20">
                <label><?php esc_html_e( 'New Password', 'homeradar-add-ons' );?><span class="dec-icon"><i class="far fa-lock-alt"></i></span></label>
                <div class="pos-relative">
                    <input type="password" name="new_pass" class="pass-input" required="required">
                    <span class="eye"><i class="far fa-eye" aria-hidden="true"></i> </span>
                </div>
            </div>
            <div class="pass-input-wrap fl-wrap hasIcon mb-20">
                <label><?php esc_html_e( 'Confirm New Password', 'homeradar-add-ons' );?><span class="dec-icon"><i class="far fa-shield-check"></i> </span></label>
                <div class="pos-relative">
                    <input type="password" name="confirm_pass" class="pass-input" required="required">
                    <span class="eye"><i class="far fa-eye" aria-hidden="true"></i> </span>
                </div>
            </div>
            <button id="change-pass-submit" class="btn color2-bg" type="submit"><?php _e( 'Save Changes', 'homeradar-add-ons' ); ?></button>
        </div>
    </form>
</div>
<!-- profile-edit-container end-->  




