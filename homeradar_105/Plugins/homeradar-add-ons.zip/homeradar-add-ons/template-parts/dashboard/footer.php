<?php
/* add_ons_php */

?>
<!-- dashboard-footer -->
<div class="dashboard-footer">
    <div class="dashboard-footer-links fl-wrap flex-items-center">
        <?php 
        if(is_active_sidebar('dbnav')){
            dynamic_sidebar('dbnav');
        } ?>
        <?php
        if ( has_nav_menu( 'dbnav' ) ) : ?>
        <span><?php _e( 'HELPFULL LINKS:', 'homeradar-add-ons' ); ?></span>
        <?php
            wp_nav_menu( array(
                'theme_location'        => 'dbnav',
                'menu_id'               => '',
                'menu_class'            => 'footer-list-inline no-list-style',
                'container'             => '',
                'container_class'       => '',
                'container_id'          => '',
                'depth'                 => 1,
                // 'link_before'    => '<span>',
                // 'link_after'     => '</span>',
            ) );

        endif;
        ?>
    </div>
    <a href="#main-theme" class="dashbord-totop  custom-scroll-link"><i class="fas fa-caret-up"></i></a>
</div>
<!-- dashboard-footer end -->  
