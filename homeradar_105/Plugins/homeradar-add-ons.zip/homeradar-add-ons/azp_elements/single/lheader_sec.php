<?php
/* add_ons_php */
azp_add_element(
    'lheader_sec',
    array(
        'name'                    => __('Header Section', 'homeradar-add-ons'),
        'category'                => __("Header", 'homeradar-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'is_section'              => true,
        'attrs'                   => array(
            // array(
            //     'type'          => 'select',
            //     'param_name'    => 'hstyle',
            //     'show_in_admin' => true,
            //     'label'         => __('Style', 'homeradar-add-ons'),
            //     'default'       => 'bgimage',
            //     'value'         => array(
            //         'bgimage'               => _x('Image Background', 'Listing Type', 'homeradar-add-ons'),
            //         'bgvideo'               => _x('Video Background', 'Listing Type', 'homeradar-add-ons'),
            //         'bgslider'              => _x('Images Slider', 'Listing Type', 'homeradar-add-ons'),
            //         'bgslideshow'           => _x('Slideshow', 'Listing Type', 'homeradar-add-ons'),
            //         'map'                   => _x('Map', 'Listing Type', 'homeradar-add-ons'),
            //         'streetview'            => _x('Street View', 'Listing Type', 'homeradar-add-ons'),
            //         'iframe'                => _x('Embed iFrame', 'Listing Type', 'homeradar-add-ons'),
            //     ),
            // ),

            array(
                'type'          => 'switch',
                'param_name'    => 'unmuted',
                // 'show_in_admin' => true,
                'label'         => _x('Unmute background video', 'Listing type', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'select',
                'param_name'    => 'images_size',
                'show_in_admin' => true,
                'label'         => __('Images Size', 'homeradar-add-ons'),
                'default'       => 'full',
                'value'         => array(
                    'full'                  => _x('Full Size', 'Listing Type', 'homeradar-add-ons'),
                    'large'                 => _x('Large size, maximum 1024px', 'Listing Type', 'homeradar-add-ons'),
                    'medium'                => _x('Medium size, maximum 300px', 'Listing Type', 'homeradar-add-ons'),
                    'homeradar-lgal'          => _x('Listing gallery size', 'Listing Type', 'homeradar-add-ons'),
                    
                ),
            ),

            array(
                'type'          => 'text',
                'param_name'    => 'slperview',
                'show_in_admin' => true,
                'label'         => _x('Sliders per view for bg slider type: number or auto', 'Listing type', 'homeradar-add-ons'),
                'default'       => 'auto',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_title',
                // 'show_in_admin' => true,
                'label'         => _x('Hide Title', 'Listing type', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_address',
                'show_in_admin' => true,
                'label'         => __('Hide Address', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'disable_address_url',
                'show_in_admin' => true,
                'label'         => _x('Disable address link', 'Listing type', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_phone',
                'show_in_admin' => true,
                'label'         => __('Hide Phone', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_email',
                'show_in_admin' => true,
                'label'         => __('Hide Email', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_web',
                // 'show_in_admin' => true,
                'label'         => _x('Show Website', 'Listing type', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_rating',
                'show_in_admin' => true,
                'label'         => __('Hide Rating', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_cats',
                'show_in_admin' => true,
                'label'         => __('Hide Category', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_share',
                // 'show_in_admin' => true,
                'label'         => _x('Show Share', 'Listing type', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_author',
                'show_in_admin' => true,
                'label'         => __('Hide Author', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_logo',
                // 'show_in_admin' => true,
                'label'         => _x('Show Logo', 'Listing type', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_status',
                'show_in_admin' => true,
                'label'         => __('Hide Open/Closed status', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'show_counter',
                'show_in_admin' => true,
                'label'         => __('Show Event Counter', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_bookmarks',
                'show_in_admin' => true,
                'label'         => __('Hide Bookmarks', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_views',
                'show_in_admin' => true,
                'label'         => __('Hide Views', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            
            
            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'share',
            //     'show_in_admin' => true,
            //     'label'         => __('Listing Share', 'homeradar-add-ons'),
            //     'desc'          => 'Show or Hide Listing Share in the posts.',
            //     'default'       => 'show',
            //     'value'         => array(
            //         'show'   => __('Show', 'homeradar-add-ons'),
            //         'hidden' => __('Hide', 'homeradar-add-ons'),
            //     ),
            // ),
            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'price',
            //     'show_in_admin' => true,
            //     'label'         => __('Listing Price', 'homeradar-add-ons'),
            //     'desc'          => 'Show or Hide Listing Price in the posts.',
            //     'default'       => 'show',
            //     'value'         => array(
            //         'show'   => __('Show', 'homeradar-add-ons'),
            //         'hidden' => __('Hide', 'homeradar-add-ons'),
            //     ),
            // ),
            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'breadcrumb',
            //     'show_in_admin' => true,
            //     'label'         => __('Breadcrumb', 'homeradar-add-ons'),
            //     'desc'          => 'Show or Hide breadcrumb in the posts.',
            //     'default'       => 'show',
            //     'value'         => array(
            //         'show'   => __('Show', 'homeradar-add-ons'),
            //         'hidden' => __('Hide', 'homeradar-add-ons'),
            //     ),
            // ),
            // array(
            //     'type'        => 'checkbox',
            //     'param_name'  => 'hide_contacts_on',
            //     // 'show_in_admin'         => true,
            //     'label'       => __('Hide contacts on', 'homeradar-add-ons'),
            //     'desc'        => __('Hide on logout user or based author plan?', 'homeradar-add-ons'),
            //     'default'     => '',
            //     'value'       => homeradar_addons_loggedin_plans_options(),
            //     'multiple'    => true,
            //     'show_toggle' => true,
            // ),

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'show_event_date',
            //     'show_in_admin' => true,
            //     'label'         => __('Show next event date?', 'homeradar-add-ons'),
            //     // 'desc'                  => '',
            //     'default'       => 'yes',
            //     'value'         => array(
            //         'yes' => __('Yes', 'homeradar-add-ons'),
            //         'no'  => __('No', 'homeradar-add-ons'),
            //     ),
            // ),

            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'homeradar-add-ons'),
                'desc'       => '',
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'homeradar-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'homeradar-add-ons'),
                'default'    => '',
            ),

        ),
    )
);
