<?php
/* add_ons_php */
azp_add_element(
    'lscrollbar_sec',
    array(
        'name'                    => __('Scroll Bar', 'homeradar-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','homeradar-add-ons'),
        'category'                => __("Navbar", 'homeradar-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => false,
        'showAnimationTab'        => false,
        'is_section'              => false,
        'attrs'                   => array(
            array(
                'type'          => 'switch',
                'param_name'    => 'show_mobile',
                'show_in_admin' => true,
                'label'         => _x('Show on mobile?', 'Listing type', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'        => 'repeater',
                'param_name'  => 'menus',
                // 'show_in_admin'         => true,
                'label'       => __('Menu Items', 'homeradar-add-ons'),
                'desc'        => '',
                'title_field' => 'rp_text',
                'fields'      => array(
                    array(
                        'type'          => 'text',
                        'param_name'    => 'title',
                        'show_in_admin' => true,
                        'label'         => __('Title', 'homeradar-add-ons'),
                        'desc'          => '',
                        'default'       => 'Details',
                    ),
                    array(
                        'type'          => 'text',
                        'param_name'    => 'sec_id',
                        'show_in_admin' => true,
                        'label'         => __('Section ID', 'homeradar-add-ons'),
                        'desc'          => '',
                        'default'       => '#details_sec',
                    ),
                    array(
                        'type'          => 'switch',
                        'param_name'    => 'show_mobile',
                        'show_in_admin' => true,
                        'label'         => __('Show on mobile?', 'homeradar-add-ons'),
                        // 'desc'                  => '',
                        'default'       => 'yes',
                        'value'         => array(
                            'yes' => __('Yes', 'homeradar-add-ons'),
                            'no'  => __('No', 'homeradar-add-ons'),
                        ),
                    ),
                    array(
                        'type'          => 'text',
                        'param_name'    => 'icon',
                        'show_in_admin' => true,
                        'label'         => __('Icon', 'homeradar-add-ons'),
                        'desc'          => '',
                        'default'       => 'fal fa-info',
                    ),
                ),
                'default'     => urlencode(json_encode(array(
                    array(
                        'title'       => 'Main',
                        'sec_id'      => '#lhead_sec',
                        'show_mobile' => 'yes',
                        'icon'        => 'fal fa-home-lg-alt',
                    ),
                    array(
                        'title'       => 'Gallery',
                        'sec_id'      => '#gallery_sec',
                        'show_mobile' => 'yes',
                        'icon'        => 'fal fa-image',
                    ),
                    array(
                        'title'       => 'Details',
                        'sec_id'      => '#details_sec',
                        'show_mobile' => 'yes',
                        'icon'        => 'fal fa-info',
                    ),
                    
                    array(
                        'title'       => 'Rooms',
                        'sec_id'      => '#rooms_sec',
                        'show_mobile' => 'yes',
                        'icon'        => 'fal fa-bed',
                    ),
                    array(
                        'title'       => 'Video',
                        'sec_id'      => '#video_sec',
                        'show_mobile' => 'yes',
                        'icon'        => 'fal fa-video',
                    ),
                    array(
                        'title'       => 'Location',
                        'sec_id'      => '#map_sec',
                        'show_mobile' => 'yes',
                        'icon'        => 'fal fa-map-pin',
                    ),
                ))),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_addtocal',
                'show_in_admin' => true,
                'label'         => _x('Show Add to Calendar?', 'Listing type', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_bookmark',
                'show_in_admin' => true,
                'label'         => __('Hide Bookmark?', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_share',
                'show_in_admin' => true,
                'label'         => __('Hide Socials share?', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_review',
                'show_in_admin' => true,
                'label'         => __('Hide Write a review?', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_report',
                'show_in_admin' => true,
                'label'         => __('Hide Report?', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'    => '',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'homeradar-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'homeradar-add-ons'),
                'default'    => '',
            ),

        ),
    )
);
