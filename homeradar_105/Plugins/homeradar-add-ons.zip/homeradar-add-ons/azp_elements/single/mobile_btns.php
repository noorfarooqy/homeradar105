<?php
/* add_ons_php */
azp_add_element(
    'mobile_btns',
    array(
        'name'                    => __('Mobile Buttons', 'homeradar-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','homeradar-add-ons'),
        'category'                => "Listing",
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'template_folder'         => 'single/',
        'attrs'                   => array(
            array(
                'type'                  => 'switch',
                'param_name'            => 'show_phone',
                'show_in_admin'         => true,
                'label'                 => __('Show phone','homeradar-add-ons'),
                'desc'                  => '',
                'default'               => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'                  => 'switch',
                'param_name'            => 'show_email',
                'show_in_admin'         => true,
                'label'                 => __('Show email','homeradar-add-ons'),
                'desc'                  => '',
                'default'               => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'                  => 'switch',
                'param_name'            => 'show_direction',
                'show_in_admin'         => true,
                'label'                 => __('Show get direction','homeradar-add-ons'),
                'desc'                  => '',
                'default'               => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'                  => 'text',
                'param_name'            => 'el_id',
                'label'                 => __('Element ID','homeradar-add-ons'),
                // 'desc'                  => '',
                'default'               => ''
            ),
            
            array(
                'type'                  => 'text',
                'param_name'            => 'el_class',
                'label'                 => __('Extra Class','homeradar-add-ons'),
                'desc'                  => __("Use this field to add a class name and then refer to it in your CSS." ,'homeradar-add-ons'),
                'default'               => ''
            ),
        ),
    )
);
