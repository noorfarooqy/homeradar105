<?php
/* add_ons_php */
azp_add_element(
    'preview_listing_content',
    array(
        'name'                    => __('Listing Card Content', 'homeradar-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','homeradar-add-ons'),
        'category'                => __("Preview Template", 'homeradar-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'is_section'              => true,
        'has_children'            => true,
        'attrs'                   => array(
            
            array(
                'type'          => 'switch',
                'param_name'    => 'hide_excerpt',
                'show_in_admin' => true,
                'label'         => __('Hide Description', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'hide_features',
                'show_in_admin' => true,
                'label'         => __('Hide Features', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'num_feature',
                'label'      => __('Number of Feature to show', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'    => '4',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_locations',
                // 'show_in_admin' => true,
                'label'         => __('Show Locations', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_price',
                // 'show_in_admin' => true,
                'label'         => __('Show Price', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_beds',
                // 'show_in_admin' => true,
                'label'         => __('Show Bedrooms', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'show_baths',
                // 'show_in_admin' => true,
                'label'         => __('Show Bathrooms', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'show_area',
                // 'show_in_admin' => true,
                'label'         => __('Show Area Size', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'show_pricerange',
            //     // 'show_in_admin' => true,
            //     'label'         => _x('Show Price range', 'Listing type', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_footer',
                'show_in_admin' => true,
                'label'         => __('Hide bottom infos ( Author - Rating )', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_author',
                'show_in_admin' => true,
                'label'         => __('Hide author', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),
            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'show_logo',
            //     // 'show_in_admin' => true,
            //     'label'         => _x('Show Logo', 'Listing type', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),
            array(
                'type'          => 'switch',
                'param_name'    => 'hide_rating',
                'show_in_admin' => true,
                'label'         => __('Hide rating', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),





            
            

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'hide_price_range',
            //     'show_in_admin' => true,
            //     'label'         => __('Hide price range', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'hide_contacts',
            //     'show_in_admin' => true,
            //     'label'         => __('Hide contact infos', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'hide_view_map',
            //     'show_in_admin' => true,
            //     'label'         => __('Hide view on map', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'hide_gallery',
            //     'show_in_admin' => true,
            //     'label'         => __('Hide gallery', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),

            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'show_web',
            //     // 'show_in_admin' => true,
            //     'label'         => _x('Show Website', 'Listing type', 'homeradar-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
            //         'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
            //     ),
            // ),


            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'homeradar-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'homeradar-add-ons'),
                'default'    => '',
            ),
        ),
    )
);
