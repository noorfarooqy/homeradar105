<?php
/* add_ons_php */
azp_add_element(
    'filter_cat',
    array(
        'name'                    => __('Category Filter', 'homeradar-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','homeradar-add-ons'),
        'category'                => __("Filter", 'homeradar-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'template_folder'         => 'filter/',
        'attrs'                   => array(
            array(
                'type'          => 'text',
                'param_name'    => 'title',
                'show_in_admin' => true,
                'label'         => __('Title', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'       => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'placeholder',
                'label'      => __('Placeholder text', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'    => 'All Categories',
            ),
            array(
                'type'        => 'checkbox',
                'param_name'  => 'cats',
                // 'show_in_admin'         => true,
                'label'       => __('Categories', 'homeradar-add-ons'),
                'desc'        => '',
                'default'     => '',
                'value'       => homeradar_addons_lcats_options(),
                'multiple'    => true,
                'show_toggle' => true,
            ),
            array(
                'type'          => 'select',
                'param_name'    => 'max_level',
                'show_in_admin' => true,
                'label'         => __('Child categories level', 'homeradar-add-ons'),
                // 'desc'                  => 'Select how to sort retrieved posts.',
                'default'       => '0',
                'value'         => array(
                    '0' => __('Hide children', 'homeradar-add-ons'),
                    '1' => __('Level 1', 'homeradar-add-ons'),
                    '2' => __('Level 2', 'homeradar-add-ons'),
                    '3' => __('Level 3', 'homeradar-add-ons'),

                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'multiple_cats',
                // 'show_in_admin' => true,
                'label'         => __('Allow select multiple categories?', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => _x('Yes', 'Yes/No option', 'homeradar-add-ons'),
                    'no'  => _x('No', 'Yes/No option', 'homeradar-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_empty',
                'show_in_admin' => true,
                'label'         => __('Hide empty child?', 'homeradar-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => __('Yes', 'homeradar-add-ons'),
                    'no'  => __('No', 'homeradar-add-ons'),
                ),
            ),
            array(
                'type'          => 'select',
                'param_name'    => 'width',
                'show_in_admin' => true,
                'label'         => __('Width', 'homeradar-add-ons'),
                // 'desc'                  => 'Select how to sort retrieved posts.',
                'default'       => '12',
                'value'         => array(
                    '12' => __('1/1', 'homeradar-add-ons'),
                    '10' => __('5/6', 'homeradar-add-ons'),
                    '9'  => __('3/4', 'homeradar-add-ons'),
                    '8'  => __('2/3', 'homeradar-add-ons'),
                    '7'  => __('7/12', 'homeradar-add-ons'),
                    '6'  => __('1/2', 'homeradar-add-ons'),
                    '5'  => __('5/12', 'homeradar-add-ons'),
                    '4'  => __('1/3', 'homeradar-add-ons'),
                    '3'  => __('1/4', 'homeradar-add-ons'),
                    '2'  => __('1/6', 'homeradar-add-ons'),
                    '1'  => __('1/12', 'homeradar-add-ons'),

                ),
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'homeradar-add-ons'),
                // 'desc'                  => '',
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'homeradar-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'homeradar-add-ons'),
                'default'    => '',
            ),

        ),
    )
);
