<?php
/**
 * @package HomeRadar – Real Estate Listing WordPress Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 05-20-2021
 * @since 1.0.0
 * @version 1.0.0
 * @copyright Copyright ( C ) 2014 - 2021 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */
// Your php code goes here
function homeradar_child_enqueue_styles() {
    $parent_style = 'homeradar-style';
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array( 'homeradar-fonts', 'homeradar-plugins' ), null );
    wp_enqueue_style( 'homeradar-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style , 'homeradar-color'),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', 'homeradar_child_enqueue_styles' );



