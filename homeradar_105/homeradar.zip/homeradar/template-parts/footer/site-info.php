<?php
/* banner-php */
/**
 * Displays footer site info
 *
 */

?>
<div class="copyright ftcopyright">
	<?php echo wp_kses( homeradar_get_option( 'footer_copyright' ), 'cth' ); ?>
</div>
