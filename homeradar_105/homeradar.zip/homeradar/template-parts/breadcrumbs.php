<?php
/* banner-php */
// if ( is_front_page() ) return;
if(!isset($is_top)) $is_top = false;
if(!isset($classes)) $classes = '';
$cls = 'inline-breadcrumbs-inner';
if($is_top) $cls = 'breadcrumbs-wrapper fw-breadcrumbs sp-brd fl-wrap';

$cls .= '' .$classes;
?>
<div class="<?php echo esc_attr( $cls ); ?>">
	<?php if($is_top) echo '<div class="container">'; ?>
	
		<div class="container-inner flex-items-center jtf-space-between flw-wrap">
			<?php homeradar_breadcrumbs(); ?>
		    <?php if( $is_top && function_exists( 'homeradar_addons_breadcrumbs_socials_share' ) ) homeradar_addons_breadcrumbs_socials_share(); ?>  
		</div>
		    
	<?php if($is_top) echo '</div>'; ?>
</div>

