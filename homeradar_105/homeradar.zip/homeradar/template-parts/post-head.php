<?php
/* banner-php */

if( get_post_meta( get_the_ID(), '_cth_show_page_header', true ) == 'yes' ) :
?>
<!--  section  -->
<section class="parallax-section hidden-section single-par2" data-scrollax-parent="true">
    <div class="bg-wrap bg-parallax-wrap-gradien">
        <div class="bg par-elem" data-bg="<?php echo esc_url( get_post_meta( get_the_ID(), '_cth_page_header_bg', true ) );?>" data-scrollax="properties: { translateY: '30%' }"></div>
    </div>
    <div class="container idx-5">
        <div class="container-inner">
            <div class="section-title center-align big-title">
                <?php if( get_post_meta(get_the_ID(),'_cth_show_page_title',true ) == 'yes') : ?>
                <<?php echo esc_attr( homeradar_get_option( 'post_heading_tag' ) );?> class="post-head-title"><span><?php single_post_title( ); ?></span></<?php echo esc_attr( homeradar_get_option( 'post_heading_tag' ) );?>>
                <?php endif ; ?>
                <?php 
                    echo wp_kses( get_post_meta( get_the_ID(), '_cth_page_header_intro', true ), 'cth' );
                ?>
            </div>
            <div class="scroll-down-wrap">
                <div class="mousey">
                    <div class="scroller"></div>
                </div>
                <span><?php echo esc_html_x( 'Scroll Down To Discover', 'Post heade', 'homeradar' ); ?></span>
            </div>
        </div>
    </div>
</section>
<!--  section  end-->
<?php endif;


