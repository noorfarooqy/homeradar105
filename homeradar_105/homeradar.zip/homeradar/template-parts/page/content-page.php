<?php
/* banner-php */
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */
$show_page_title = get_post_meta( get_the_ID(), '_cth_show_page_title', true );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('single-page-content-wrap'); ?>>
	<?php 
	if( get_post_meta( get_the_ID(), '_cth_show_page_title', true ) != 'yes' ): ?>
	<div class="single-page-title-inside">
		<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
	</div><!-- .list-single-main-item-title-->
	<?php endif; ?>
	<?php homeradar_edit_link( get_the_ID() ); ?>
	<div class="entry-content clearfix">
		<?php
			the_content();
		?>
		<div class="clearfix"></div>
	</div><!-- .entry-content -->
	<?php
		homeradar_link_pages();
	?>
</article><!-- #post-## -->
