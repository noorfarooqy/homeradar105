<?php
/* banner-php */
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */
get_header(); ?>
<section class="parallax-section color-bg ovf-hidden" data-scrollax-parent="true" id="main-sec">
    <div class="container idx-5">
        <div class="error-wrap">
            <div class="hero-text-big"><?php esc_html_e( 'Protected','homeradar' ); ?></div>
            <div class="protected-title"><?php the_title( );?></div>
            <div class="clearfix"></div>
            <?php echo get_the_password_form(); ?>
            <div class="clearfix"></div>
            <?php 
            if( homeradar_get_option( 'error404_btn' ) ) : 
            ?>
                <p><?php esc_html_e( 'Or', 'homeradar' );?></p>
                <a href="<?php echo esc_url( home_url() );?>" class="btn color-bg"><?php esc_html_e( 'Back to Home Page', 'homeradar' ); ?></a>
            <?php 
            endif; ?>
        </div>
    </div>
    <div class="pwh_bg fw-pwh" data-bg="<?php echo esc_url( homeradar_get_attachment_thumb_link( homeradar_get_option( 'error404_bg' ), 'full' ) );?>">
        <div class="mrb_pin vis_mr mrb_pin3 "></div>
        <div class="mrb_pin vis_mr mrb_pin4 "></div>
    </div>
</section>
<!--  section  -->

<?php     
get_footer();
