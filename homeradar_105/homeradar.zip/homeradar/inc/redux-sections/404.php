<?php
/* banner-php */

Redux::setSection( $opt_name, array(
    'title' => esc_html__('404 Page', 'homeradar'),
    'id'         => 'error-page-settings',
    'subsection' => false,
    
    'icon'       => 'el-icon-file-edit',
    'fields' => array(
        array(
            'id'      => 'error404_bg',
            'type'    => 'image_id',
            'title'   => esc_html__('Background Image', 'homeradar'),
            'default' => '',
        ),

        array(
            'id' => 'error404_msg',
            'type' => 'textarea',
            'title' => esc_html__('Additional Message', 'homeradar'),
            'default' => '<p>We\'re sorry, but the Page you were looking for, couldn\'t be found.</p>'
        ),
        array(
            'id'      => 'error404_btn',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show back Home', 'homeradar'),
            'default' => true,

        ),


        
    ),
) );

