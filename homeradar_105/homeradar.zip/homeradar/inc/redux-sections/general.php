<?php
/* banner-php */
// -> START General Settings

Redux::setSection($opt_name, array(
    'title'      => esc_html__('General', 'homeradar'),
    'id'         => 'general-settings',
    'subsection' => false,

    'icon'       => 'el-icon-cogs',
    'fields'     => array(

        array(
            'id'      => 'show_loader',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Loader', 'homeradar'),
            'default' => true,

        ),

        array(
            'id'      => 'loader_icon',
            'type'    => 'image_id',
            'title'   => esc_html__('Loader Icon', 'homeradar'),
            'default' => '',
        ),

        array(
            'id'      => 'post_heading_tag',
            'type'    => 'select',
            'title'   => esc_html__('Post heading HTML tag', 'homeradar'),
            'options' => array(
                'h1' => esc_html_x('H1', 'Theme option', 'homeradar'),
                'h2' => esc_html_x('H2', 'Theme option', 'homeradar'),
                'h3' => esc_html_x('H3', 'Theme option', 'homeradar'),
                'h4' => esc_html_x('H4', 'Theme option', 'homeradar'),
                'h5' => esc_html_x('H5', 'Theme option', 'homeradar'),
                'h6' => esc_html_x('H6', 'Theme option', 'homeradar'),
                
            ),
            'default' => 'h1',
        ),

        array(
            'id'      => 'enable_auto_update',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Enable Auto Update', 'homeradar'),
            'desc'    => esc_html__('Note: auto update feature is not for Envato Elements download.', 'homeradar'),
            'default' => false,
        ),



    ),
));
