<?php
/* banner-php */

Redux::setSection( $opt_name, array(
    'title' => esc_html__('Footer', 'homeradar'),
    'id'         => 'footer-settings',
    'subsection' => false,
    
    'icon'       => 'el-icon-pencil',
    'fields' => array(
        array(
            'id'      => 'footer_logo',
            'type'    => 'image_id',
            'title'   => esc_html__('Footer Logo', 'homeradar'),
            'default' => '',
        ),

        array(
            'id'      => 'footer_copyright',
            'type'    => 'textarea',
            'title'   => esc_html__('Copyright Text', 'homeradar'),
            'default' => '<span class="ft-copy">&#169; <a href="https://themeforest.net/user/cththemes" target="_blank">CTHthemes</a> 2021.  All rights reserved.</span>',
        ),


        array(
            'id'      => 'hide_totop',
            'type'    => 'switch',
            'on'      => esc_html_x('Yes', 'Yes/No option', 'homeradar'),
            'off'     => esc_html_x('No', 'Yes/No option', 'homeradar'),
            'title'   => esc_html__('Hide go to Top button?', 'homeradar'),
            'default' => false,

        ),

    ),
) );