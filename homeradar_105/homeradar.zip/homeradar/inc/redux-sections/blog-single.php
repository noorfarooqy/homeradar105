<?php
/* banner-php */

Redux::setSection( $opt_name, array(
    'title' => esc_html__('Blog Single', 'homeradar'),
    'id'         => 'blog-single-optons',
    'subsection' => true,
    'fields' => array(

        array(
            'id'      => 'blog-single-sidebar-width',
            'type'    => 'select',
            'title'   => esc_html__('Sidebar Width', 'homeradar'),
            'desc'       => esc_html__( 'Based on Bootstrap 12 columns.', 'homeradar' ),
            'options' => array(
                '2' => esc_html__('2 Columns', 'homeradar'),
        '3' => esc_html__('3 Columns', 'homeradar'),
        '4' => esc_html__('4 Columns', 'homeradar'),
        '5' => esc_html__('5 Columns', 'homeradar'),
        '6' => esc_html__('6 Columns', 'homeradar'),
            ),
            'default' => '4',
        ),

        array(
            'id'      => 'single_title_tag',
            'type'    => 'select',
            'title'   => esc_html__('Title HTML tag', 'homeradar'),
            'options' => array(
                'h1' => esc_html_x('H1', 'Theme option', 'homeradar'),
                'h2' => esc_html_x('H2', 'Theme option', 'homeradar'),
                'h3' => esc_html_x('H3', 'Theme option', 'homeradar'),
                'h4' => esc_html_x('H4', 'Theme option', 'homeradar'),
                'h5' => esc_html_x('H5', 'Theme option', 'homeradar'),
                'h6' => esc_html_x('H6', 'Theme option', 'homeradar'),
                
            ),
            'default' => 'h1',
        ),

        

        array(
            'id'      => 'single_featured',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Featured Image', 'homeradar'),
            'default' => true,

        ),
        array(
            'id'      => 'single_author',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Author', 'homeradar'),
            'default' => true,

        ),
        
        array(
            'id'      => 'single_date',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Date', 'homeradar'),
            'default' => true,

        ),
        

        array(
            'id'      => 'single_cats',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Categories', 'homeradar'),
            'default' => true,

        ),

        array(
            'id'      => 'single_tags',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Tags', 'homeradar'),
            'default' => true,

        ),

        array(
            'id'      => 'single_comments',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Comments', 'homeradar'),
            'default' => false,

        ),

        array(
            'id'      => 'single_author_block',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show Author Block', 'homeradar'),
            'default' => false,

        ),

        array(
            'id'      => 'single_post_nav',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Show post navigation', 'homeradar'),
            'default' => true,

        ),

        array(
            'id'      => 'single_same_term',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'homeradar'),
            'off'     => esc_html__('No', 'homeradar'),
            'title'   => esc_html__('Next/Prev posts should be in same category', 'homeradar'),
            'default' => false,

        ),

          
    ),
));
