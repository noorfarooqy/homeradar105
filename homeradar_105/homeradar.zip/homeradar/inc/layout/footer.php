<?php
/* banner-php */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! function_exists( 'homeradar_footer_content' ) ) {
    add_action( 'homeradar_footer', 'homeradar_footer_content' );
    
    function homeradar_footer_content() {
        ?>
        <!--footer -->
        <footer class="homeradar-footer main-footer fl-wrap">  
            
            <!--sub-footer-->
            <div class="sub-footer gray-bg fl-wrap">
                <div class="container">
                    <div class="row flex-items-centers sub-footer-row flw-wrap">
                        <?php 
                        if(is_active_sidebar('footer-menu')){  
                            echo '<div class="col-md-6 col-sm-12 col-xs-12 subfooter-info-wrap">';
                                get_template_part( 'template-parts/footer/site', 'info' );
                            echo '</div>';
                            echo '<div class="col-md-6 col-sm-12 col-xs-12 subfooter-menu-wraps subfooter-widgets-wrap">';
                                dynamic_sidebar('footer-menu');
                            echo '</div>';
                        }else{ ?>
                        <div class="col-md-12 subfooter-info-wrap">
                            <?php 
                            get_template_part( 'template-parts/footer/site', 'info' );
                            ?>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <!--sub-footer end -->    
            

        </footer>
        <!--footer end  -->
        <?php
    }
}
