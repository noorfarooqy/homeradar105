<?php
/* banner-php */
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 */

                do_action( 'homeradar_footer_before' );
?>
                </div>
                <!-- Content end -->

                <?php do_action( 'homeradar_wrapper_end' ); ?>


            </div>
            <!-- wrapper end -->
            <div class="clearfix"></div>

            <?php 
            $head_carts = homeradar_get_header_cart_link();
            if (  !empty($head_carts) ) {
            ?>
            <!--cart  --> 
            <div class="show-cart color2-bg"><i class="far fa-shopping-cart"></i><span class="cart-count"><?php echo esc_html($head_carts['count'] );?></span></div>
            <div class="cart-overlay"></div>
            <div class="cart-modal">
                <div class="cart-modal-wrap fl-wrap">
                    <span class="close-cart color2-bg"><?php esc_html_e( 'Close ', 'homeradar' ); ?><i class="fal fa-times"></i> </span>
                    <h3><?php esc_html_e( 'Your cart', 'homeradar' ); ?></h3>
                    <div class="widget_shopping_cart_content"></div>
                    
                </div>
            </div>
            <!--cart end-->  
            <?php 
            }
            ?>
            
            <?php do_action( 'homeradar_footer' ); ?>
            

            
        </div>
        <!-- Main end -->
        <?php wp_footer(); ?>
    </body>
</html>
